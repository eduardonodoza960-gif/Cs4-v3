package com.cs.reliquia.mixin.client;

import com.cs.reliquia.CsReliquia;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Com o Lampião Lendário na mão: na SUA terceira pessoa a armadura e os itens das mãos
 * não são desenhados. Primeira pessoa e inventário continuam normais.
 */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {

    @Unique
    private int[] cs$slots = null;
    @Unique
    private ItemStack[] cs$guardados = null;

    @Inject(method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
            at = @At("HEAD"))
    private void cs$esconder(AbstractClientPlayerEntity player, PlayerEntityRenderState state, float delta, CallbackInfo ci) {
        cs$slots = null;
        cs$guardados = null;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (player != mc.player) return;
        // primeira pessoa (sem tela aberta) não desenha o corpo; terceira pessoa e o boneco do inventário sim
        if (mc.currentScreen == null && mc.options.getPerspective().isFirstPerson()) return;

        PlayerInventory inv = player.getInventory();
        boolean lampiao = CsReliquia.temId(player.getMainHandStack(), CsReliquia.LAMPIAO_ID)
                       || CsReliquia.temId(player.getOffHandStack(), CsReliquia.LAMPIAO_ID);
        if (!lampiao) return;

        // 36 botas, 37 calças, 38 peitoral, 39 capacete, 40 mão secundária, e o slot da mão principal
        int[] slots = {36, 37, 38, 39, 40, inv.selectedSlot};
        ItemStack[] guardados = new ItemStack[slots.length];
        for (int i = 0; i < slots.length; i++) {
            ItemStack atual = inv.getStack(slots[i]);
            guardados[i] = atual;
            boolean manter = (slots[i] == 38 && atual.isOf(Items.ELYTRA))
                          || (slots[i] == 39 && atual.isOf(Items.CARVED_PUMPKIN));
            if (!manter) inv.setStack(slots[i], ItemStack.EMPTY);
        }
        cs$slots = slots;
        cs$guardados = guardados;
    }

    @Inject(method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
            at = @At("TAIL"))
    private void cs$restaurar(AbstractClientPlayerEntity player, PlayerEntityRenderState state, float delta, CallbackInfo ci) {
        if (cs$slots == null) return;
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < cs$slots.length; i++) {
            inv.setStack(cs$slots[i], cs$guardados[i]);
        }
        cs$slots = null;
        cs$guardados = null;
    }
}
