package com.cs.reliquia.mixin;

import com.cs.reliquia.CsReliquia;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockItem.class)
public abstract class BlockItemMixin {

    // Dragão Lendário e Lampião Lendário nunca são colocados no chão
    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;",
            at = @At("HEAD"), cancellable = true)
    private void cs$naoColocar(ItemPlacementContext ctx, CallbackInfoReturnable<ActionResult> cir) {
        ItemStack stack = ctx.getStack();
        if (CsReliquia.isReliquia(stack)) {
            if (!ctx.getWorld().isClient() && ctx.getPlayer() instanceof ServerPlayerEntity sp
                    && CsReliquia.temId(stack, CsReliquia.DRAGAO_ID)) {
                CsReliquia.dispararBafo(sp, stack); // clicar num bloco também solta o bafo
            }
            cir.setReturnValue(ActionResult.FAIL);
        }
    }
}
