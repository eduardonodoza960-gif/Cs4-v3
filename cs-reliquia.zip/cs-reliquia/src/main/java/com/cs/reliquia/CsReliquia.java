package com.cs.reliquia;

import com.cs.reliquia.mixin.PlayerEntityAccessor;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.network.packet.s2c.play.EntitiesDestroyS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySetHeadYawS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityTrackerUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.potion.PotionUtil;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;

import static net.minecraft.server.command.CommandManager.literal;

public class CsReliquia implements ModInitializer {

    public static final String TAG = "CsItem";
    public static final String ESPADA_ID = "espada_cacador";
    public static final String PENA_ID = "pena_lendaria";
    public static final String ESCUDO_ID = "escudo_lendario";
    public static final String POCAO_ID = "pocao_lendaria";
    public static final String TRIDENTE_ID = "tridente_lendario";
    public static final String PICARETA_ID = "picareta_lendaria";
    public static final String CAPACETE_ID = "capacete_gemeos";
    public static final String DRAGAO_ID = "dragao_area";
    public static final String RELOGIO_ID = "relogio_lendario";
    public static final String LAMPIAO_ID = "lampiao_lendario";
    public static final String BUSSOLA_ID = "bussola_lendaria";
    public static final String BATATA_ID = "batata_do_bobo";
    public static final String BOTA_ID = "bota_lendaria";

    // ---- Rajada do Warden (Escudo) ----
    private static final double ALCANCE = 15.0;
    private static final float DANO = 3.5f;
    private static final double KB_HORIZONTAL = 1.2;
    private static final double KB_VERTICAL = 0.5;
    private static final int COOLDOWN_ESCUDO = 200;   // 10 s
    // ---- Poção ----
    private static final int COOLDOWN_POCAO = 100;    // 5 s
    // ---- Bafo do Dragão ----
    private static final int COOLDOWN_DRAGAO = 200;   // 10 s
    private static final float BAFO_RAIO = 3.0f;
    private static final int BAFO_DURACAO = 100;      // 5 s
    private static final float BAFO_DANO = 4.0f;      // a cada 1 s dentro da nuvem

    private static final Map<UUID, Integer> ULTIMO_ESCUDO = new HashMap<>();
    private static final Map<UUID, Integer> RAIO_MARCADO = new HashMap<>();
    private static final Set<UUID> GEMEOS = new HashSet<>();

    /** IDs de entidades (jogadores) com equipamento escondido por causa do Lampião. */
    public static final Set<Integer> OCULTOS = ConcurrentHashMap.newKeySet();

    // ---- Skins ----
    private static final Map<UUID, GameProfile> ORIGINAIS = new HashMap<>();
    private static final Map<UUID, Disfarce> DISFARCES = new HashMap<>();

    private static class Disfarce {
        UUID alvo;
        String textura;
        Disfarce(UUID alvo, String textura) { this.alvo = alvo; this.textura = textura; }
    }

    private static class Bafo {
        ServerWorld mundo; double x, y, z; UUID dono; int inicio, fim;
    }
    private static final List<Bafo> BAFOS = new ArrayList<>();

    public static void marcarRaio(UUID uuid, int tick) {
        RAIO_MARCADO.put(uuid, tick);
    }

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(literal("cs4").executes(ctx -> {
                abrirMenu(ctx.getSource().getPlayerOrThrow());
                return 1;
            }))
        );

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity p = handler.player;
            ORIGINAIS.remove(p.getUuid());
            DISFARCES.remove(p.getUuid());
            OCULTOS.remove(p.getId());
            GEMEOS.remove(p.getUuid());
        });

        // "Comando de repetição": roda todo tick no servidor
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int tick = server.getTicks();
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                ItemStack main = player.getMainHandStack();
                ItemStack off = player.getOffHandStack();

                if (temId(main, ESPADA_ID) || temId(off, ESPADA_ID)) {
                    aplicar(player, StatusEffects.BAD_OMEN, 5, 20);
                }
                if (temId(main, PENA_ID) || temId(off, PENA_ID)) {
                    aplicar(player, StatusEffects.LEVITATION, 12, 80);
                }

                // Capacete dos Gêmeos
                if (temId(player.getEquippedStack(EquipmentSlot.HEAD), CAPACETE_ID)) {
                    GEMEOS.add(player.getUuid());
                    aplicar(player, StatusEffects.WATER_BREATHING, 0, 40);
                } else {
                    GEMEOS.remove(player.getUuid());
                }

                // Bota Lendária (vale também depois de virar netherite): Velocidade 5, 4s
                if (temId(player.getEquippedStack(EquipmentSlot.FEET), BOTA_ID)) {
                    aplicar(player, StatusEffects.SPEED, 4, 80);
                }

                // Lampião Lendário: Invisibilidade 13, 1s + esconde armadura/itens dos outros
                boolean lampiao = temId(main, LAMPIAO_ID) || temId(off, LAMPIAO_ID);
                if (lampiao) {
                    aplicar(player, StatusEffects.INVISIBILITY, 12, 20);
                }
                atualizarOcultacao(player, lampiao);

                // Batata do Bobo no inventário: Lentidão 5, 1s
                if (temNoInventario(player, BATATA_ID)) {
                    aplicar(player, StatusEffects.SLOWNESS, 4, 20);
                }

                // Bússola: aponta para o alvo
                if (tick % 10 == 0) {
                    for (int i = 0; i < player.getInventory().size(); i++) {
                        ItemStack s = player.getInventory().getStack(i);
                        if (temId(s, BUSSOLA_ID)) atualizarBussola(s, server);
                    }
                }
            }
            if (tick % 20 == 0) acompanharSkins(server);
            processarBafos(server, tick);
        });

        // Botão direito
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient || !(player instanceof ServerPlayerEntity sp)) {
                return TypedActionResult.pass(stack);
            }

            if (temId(stack, ESCUDO_ID)) {
                int agora = sp.getServer().getTicks();
                Integer ultimo = ULTIMO_ESCUDO.get(sp.getUuid());
                if (ultimo == null || agora - ultimo >= COOLDOWN_ESCUDO) {
                    ULTIMO_ESCUDO.put(sp.getUuid(), agora);
                    soltarRajada(sp);
                }
                return TypedActionResult.pass(stack);
            }

            if (temId(stack, POCAO_ID)) {
                if (sp.getItemCooldownManager().isCoolingDown(Items.SPLASH_POTION)) {
                    return TypedActionResult.fail(stack);
                }
                lancarPocao(sp, stack);
                return TypedActionResult.success(stack);
            }

            if (temId(stack, DRAGAO_ID)) {
                return dispararBafo(sp) ? TypedActionResult.success(stack) : TypedActionResult.fail(stack);
            }

            if (temId(stack, RELOGIO_ID)) {
                abrirSelecao(sp, false, CsReliquia::trocarSkin);
                return TypedActionResult.success(stack);
            }

            if (temId(stack, BUSSOLA_ID)) {
                abrirSelecao(sp, true, (eu, alvo) -> escolherAlvo(eu, alvo, hand));
                return TypedActionResult.success(stack);
            }
            return TypedActionResult.pass(stack);
        });

        // Tridente Lendário na mão
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient && entity instanceof LivingEntity alvo
                    && temId(player.getStackInHand(hand), TRIDENTE_ID)) {
                alvo.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 200, 2), player);
            }
            return ActionResult.PASS;
        });

        // Mortes
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof ServerPlayerEntity morto)) return;
            MinecraftServer server = morto.getServer();
            OCULTOS.remove(morto.getId());

            Integer marca = RAIO_MARCADO.remove(morto.getUuid());
            if (marca != null && server.getTicks() - marca <= 60) {
                morto.getInventory().clear();
                ServerWorld mundo = (ServerWorld) morto.world;
                List<ItemEntity> drops = mundo.getEntitiesByClass(ItemEntity.class,
                    morto.getBoundingBox().expand(4.0), i -> i.getItemAge() <= 5);
                for (ItemEntity drop : drops) drop.discard();
            }

            if (GEMEOS.remove(morto.getUuid())) {
                for (ServerPlayerEntity outro : server.getPlayerManager().getPlayerList()) {
                    if (outro != morto && outro.isAlive() && GEMEOS.contains(outro.getUuid())) {
                        GEMEOS.remove(outro.getUuid());
                        outro.damage(DamageSource.OUT_OF_WORLD, Float.MAX_VALUE);
                    }
                }
            }
        });
    }

    private static void aplicar(ServerPlayerEntity player, StatusEffect efeito, int amplificador, int duracao) {
        StatusEffectInstance atual = player.getStatusEffect(efeito);
        if (atual == null || atual.getDuration() <= 10 || atual.getAmplifier() != amplificador) {
            player.addStatusEffect(new StatusEffectInstance(efeito, duracao, amplificador, false, false, true));
        }
    }

    private static boolean temNoInventario(ServerPlayerEntity p, String id) {
        for (int i = 0; i < p.getInventory().size(); i++) {
            if (temId(p.getInventory().getStack(i), id)) return true;
        }
        return false;
    }

    // ---------- Poção Lendária ----------
    private void lancarPocao(ServerPlayerEntity player, ItemStack stack) {
        ServerWorld world = (ServerWorld) player.world;

        ItemStack lingering = new ItemStack(Items.LINGERING_POTION);
        lingering.setNbt(stack.getNbt().copy());

        PotionEntity entity = new PotionEntity(world, player);
        entity.setItem(lingering);
        entity.setVelocity(player, player.getPitch(), player.getYaw(), -20.0F, 0.5F, 1.0F);
        world.spawnEntity(entity);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_LINGERING_POTION_THROW, SoundCategory.PLAYERS, 0.5F,
            0.4F / (world.getRandom().nextFloat() * 0.4F + 0.8F));

        if (!player.getAbilities().creativeMode) stack.decrement(1);
        player.getItemCooldownManager().set(Items.SPLASH_POTION, COOLDOWN_POCAO);
    }

    // ---------- Bafo do Dragão ----------
    public static boolean dispararBafo(ServerPlayerEntity player) {
        if (player.getItemCooldownManager().isCoolingDown(Items.DRAGON_HEAD)) return false;
        ServerWorld world = (ServerWorld) player.world;

        Vec3d inicio = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0f);
        Vec3d fim = inicio.add(dir.multiply(8.0));
        var bloco = world.raycast(new RaycastContext(inicio, fim,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        if (bloco.getType() != HitResult.Type.MISS) {
            fim = bloco.getPos().subtract(dir.multiply(0.3));
        }

        double comp = inicio.distanceTo(fim);
        for (double d = 1.0; d < comp; d += 0.5) {
            Vec3d p = inicio.add(dir.multiply(d));
            world.spawnParticles(ParticleTypes.DRAGON_BREATH, p.x, p.y, p.z, 3, 0.15, 0.15, 0.15, 0.01);
        }

        AreaEffectCloudEntity nuvem = new AreaEffectCloudEntity(world, fim.x, fim.y, fim.z);
        nuvem.setOwner(player);
        nuvem.setParticleType(ParticleTypes.DRAGON_BREATH);
        nuvem.setRadius(BAFO_RAIO);
        nuvem.setDuration(BAFO_DURACAO);
        nuvem.setWaitTime(0);
        world.spawnEntity(nuvem);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_ENDER_DRAGON_SHOOT, SoundCategory.PLAYERS, 1.0f, 1.0f);

        Bafo b = new Bafo();
        b.mundo = world; b.x = fim.x; b.y = fim.y; b.z = fim.z;
        b.dono = player.getUuid();
        b.inicio = player.getServer().getTicks();
        b.fim = b.inicio + BAFO_DURACAO;
        BAFOS.add(b);

        player.getItemCooldownManager().set(Items.DRAGON_HEAD, COOLDOWN_DRAGAO);
        return true;
    }

    private static void processarBafos(MinecraftServer server, int tick) {
        Iterator<Bafo> it = BAFOS.iterator();
        while (it.hasNext()) {
            Bafo b = it.next();
            if (tick >= b.fim) { it.remove(); continue; }
            if ((tick - b.inicio) % 20 != 0) continue;
            Box caixa = new Box(b.x - BAFO_RAIO, b.y - 1.0, b.z - BAFO_RAIO,
                                b.x + BAFO_RAIO, b.y + 2.0, b.z + BAFO_RAIO);
            for (LivingEntity e : b.mundo.getEntitiesByClass(LivingEntity.class, caixa,
                    x -> x.isAlive() && !x.getUuid().equals(b.dono))) {
                double dx = e.getX() - b.x, dz = e.getZ() - b.z;
                if (dx * dx + dz * dz <= BAFO_RAIO * BAFO_RAIO) {
                    e.damage(DamageSource.DRAGON_BREATH, BAFO_DANO);
                }
            }
        }
    }

    // ---------- Rajada do Warden ----------
    private void soltarRajada(ServerPlayerEntity player) {
        ServerWorld world = (ServerWorld) player.world;
        Vec3d inicio = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0f);
        Vec3d fim = inicio.add(dir.multiply(ALCANCE));

        var bloco = world.raycast(new RaycastContext(inicio, fim,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        if (bloco.getType() != HitResult.Type.MISS) {
            fim = bloco.getPos();
        }
        double comprimento = inicio.distanceTo(fim);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 3.0f, 1.0f);

        for (int i = 1; i < (int) Math.floor(comprimento); i++) {
            Vec3d p = inicio.add(dir.multiply(i));
            world.spawnParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }

        Box area = new Box(inicio, fim).expand(1.5);
        List<Entity> alvos = world.getOtherEntities(player, area,
            e -> e instanceof LivingEntity && e.isAlive());
        for (Entity e : alvos) {
            if (e.getBoundingBox().expand(0.6).raycast(inicio, fim).isEmpty()) continue;
            LivingEntity alvo = (LivingEntity) e;

            alvo.damage(DamageSource.sonicBoom(player), DANO);

            Vec3d horizontal = new Vec3d(dir.x, 0, dir.z);
            horizontal = horizontal.lengthSquared() < 1.0E-4 ? dir : horizontal.normalize();
            alvo.setVelocity(horizontal.x * KB_HORIZONTAL, KB_VERTICAL, horizontal.z * KB_HORIZONTAL);
            alvo.velocityModified = true;
            if (alvo instanceof ServerPlayerEntity alvoPlayer) {
                alvoPlayer.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(alvoPlayer));
            }
        }
    }

    // ---------- Lampião: esconder equipamento ----------
    public static List<Pair<EquipmentSlot, ItemStack>> filtrarEquipamento(List<Pair<EquipmentSlot, ItemStack>> original) {
        List<Pair<EquipmentSlot, ItemStack>> nova = new ArrayList<>();
        for (Pair<EquipmentSlot, ItemStack> par : original) {
            EquipmentSlot slot = par.getFirst();
            ItemStack s = par.getSecond();
            boolean manter = (slot == EquipmentSlot.CHEST && s.isOf(Items.ELYTRA))
                          || (slot == EquipmentSlot.HEAD && s.isOf(Items.CARVED_PUMPKIN));
            nova.add(manter ? par : Pair.of(slot, ItemStack.EMPTY));
        }
        return nova;
    }

    private static EntityEquipmentUpdateS2CPacket pacoteEquipamento(ServerPlayerEntity p) {
        List<Pair<EquipmentSlot, ItemStack>> lista = new ArrayList<>();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            lista.add(Pair.of(slot, p.getEquippedStack(slot)));
        }
        return new EntityEquipmentUpdateS2CPacket(p.getId(), lista);
    }

    private static void enviarEquipamento(ServerPlayerEntity p) {
        EntityEquipmentUpdateS2CPacket pacote = pacoteEquipamento(p);
        for (ServerPlayerEntity v : PlayerLookup.tracking(p)) {
            if (v != p) v.networkHandler.sendPacket(pacote);
        }
    }

    private static void atualizarOcultacao(ServerPlayerEntity p, boolean oculto) {
        boolean ja = OCULTOS.contains(p.getId());
        if (oculto && !ja) {
            OCULTOS.add(p.getId());
            enviarEquipamento(p);
        } else if (!oculto && ja) {
            OCULTOS.remove(p.getId());
            enviarEquipamento(p);
        }
    }

    // ---------- Skins (Relógio Lendário) ----------
    private static GameProfile original(ServerPlayerEntity p) {
        return ORIGINAIS.computeIfAbsent(p.getUuid(), k -> p.getGameProfile());
    }

    private static String textura(GameProfile perfil) {
        for (Property prop : perfil.getProperties().get("textures")) {
            return prop.getValue();
        }
        return "";
    }

    private static void trocarSkin(ServerPlayerEntity eu, UUID alvoUuid) {
        if (alvoUuid.equals(eu.getUuid())) {
            // voltar para a própria skin
            GameProfile orig = original(eu);
            ((PlayerEntityAccessor) eu).cs$setGameProfile(orig);
            DISFARCES.remove(eu.getUuid());
            atualizarAparencia(eu);
            return;
        }
        ServerPlayerEntity alvo = eu.getServer().getPlayerManager().getPlayer(alvoUuid);
        if (alvo == null) return;
        aplicarDisfarce(eu, alvo);
    }

    private static void aplicarDisfarce(ServerPlayerEntity eu, ServerPlayerEntity alvo) {
        GameProfile origEu = original(eu);
        GameProfile origAlvo = original(alvo);

        GameProfile falso = new GameProfile(origEu.getId(), origAlvo.getName());
        falso.getProperties().putAll(origAlvo.getProperties());
        ((PlayerEntityAccessor) eu).cs$setGameProfile(falso);

        DISFARCES.put(eu.getUuid(), new Disfarce(alvo.getUuid(), textura(origAlvo)));
        atualizarAparencia(eu);
    }

    /** Se o alvo trocar de skin (por outro mod), quem está usando a skin dele acompanha. */
    private static void acompanharSkins(MinecraftServer server) {
        for (UUID uuid : new ArrayList<>(DISFARCES.keySet())) {
            Disfarce d = DISFARCES.get(uuid);
            ServerPlayerEntity eu = server.getPlayerManager().getPlayer(uuid);
            ServerPlayerEntity alvo = server.getPlayerManager().getPlayer(d.alvo);
            if (eu == null || alvo == null) continue;
            String atual = textura(original(alvo));
            if (!atual.equals(d.textura)) {
                aplicarDisfarce(eu, alvo);
            }
        }
    }

    private static void atualizarAparencia(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        Set<ServerPlayerEntity> vendo = new HashSet<>(PlayerLookup.tracking(p));
        vendo.remove(p);

        PlayerListS2CPacket remover = new PlayerListS2CPacket(PlayerListS2CPacket.Action.REMOVE_PLAYER, p);
        PlayerListS2CPacket adicionar = new PlayerListS2CPacket(PlayerListS2CPacket.Action.ADD_PLAYER, p);

        for (ServerPlayerEntity v : server.getPlayerManager().getPlayerList()) {
            boolean ve = vendo.contains(v);
            if (ve) v.networkHandler.sendPacket(new EntitiesDestroyS2CPacket(p.getId()));
            v.networkHandler.sendPacket(remover);
            v.networkHandler.sendPacket(adicionar);
            if (ve) {
                v.networkHandler.sendPacket(p.createSpawnPacket());
                v.networkHandler.sendPacket(new EntityTrackerUpdateS2CPacket(p.getId(), p.getDataTracker(), true));
                v.networkHandler.sendPacket(pacoteEquipamento(p));
                v.networkHandler.sendPacket(new EntitySetHeadYawS2CPacket(p,
                    (byte) MathHelper.floor(p.getHeadYaw() * 256.0f / 360.0f)));
            }
        }
    }

    // ---------- Bússola Lendária ----------
    private static void escolherAlvo(ServerPlayerEntity eu, UUID alvoUuid, Hand hand) {
        ServerPlayerEntity alvo = eu.getServer().getPlayerManager().getPlayer(alvoUuid);
        if (alvo == null) return;

        ItemStack bussola = eu.getStackInHand(hand);
        if (!temId(bussola, BUSSOLA_ID)) {
            bussola = ItemStack.EMPTY;
            for (int i = 0; i < eu.getInventory().size(); i++) {
                ItemStack s = eu.getInventory().getStack(i);
                if (temId(s, BUSSOLA_ID)) { bussola = s; break; }
            }
        }
        if (bussola.isEmpty()) return;

        bussola.getOrCreateNbt().putString("CsAlvo", alvoUuid.toString());
        atualizarBussola(bussola, eu.getServer());

        eu.sendMessage(Text.literal("\u00a7aVoc\u00ea Selecionou o Jogador \u00a7f"
            + original(alvo).getName() + " \u00a7acomo alvo"), false);
    }

    private static void atualizarBussola(ItemStack s, MinecraftServer server) {
        NbtCompound nbt = s.getOrCreateNbt();
        String a = nbt.getString("CsAlvo");
        ServerPlayerEntity alvo = null;
        if (!a.isEmpty()) {
            try {
                alvo = server.getPlayerManager().getPlayer(UUID.fromString(a));
            } catch (IllegalArgumentException ignored) { }
        }

        if (alvo == null) {
            // alvo saiu: volta a apontar para o ponto de ressurgimento do mundo
            if (nbt.contains("LodestonePos") || nbt.contains("LodestoneDimension")) {
                nbt.remove("LodestonePos");
                nbt.remove("LodestoneDimension");
                nbt.remove("LodestoneTracked");
            }
            return;
        }

        BlockPos pos = alvo.getBlockPos();
        String dim = alvo.world.getRegistryKey().getValue().toString();
        boolean atualizar = !nbt.contains("LodestonePos")
            || !dim.equals(nbt.getString("LodestoneDimension"))
            || NbtHelper.toBlockPos(nbt.getCompound("LodestonePos")).getSquaredDistance(pos) >= 4;
        if (atualizar) {
            nbt.put("LodestonePos", NbtHelper.fromBlockPos(pos));
            nbt.putString("LodestoneDimension", dim);
            nbt.putBoolean("LodestoneTracked", false);
        }
    }

    // ---------- Menus ----------
    private void abrirSelecao(ServerPlayerEntity player, boolean excluirEu, BiConsumer<ServerPlayerEntity, UUID> acao) {
        List<ServerPlayerEntity> jogadores = new ArrayList<>(player.getServer().getPlayerManager().getPlayerList());
        if (excluirEu) jogadores.remove(player);

        int linhas = Math.max(1, Math.min(6, (jogadores.size() + 8) / 9));
        SimpleInventory inv = new SimpleInventory(linhas * 9) {
            @Override
            public boolean isValid(int slot, ItemStack stack) {
                return false;
            }
        };
        List<UUID> ids = new ArrayList<>();
        for (int i = 0; i < jogadores.size() && i < linhas * 9; i++) {
            ServerPlayerEntity j = jogadores.get(i);
            inv.setStack(i, cabeca(original(j)));
            ids.add(j.getUuid());
        }

        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (syncId, pinv, p) -> new MenuSelecao(syncId, pinv, inv, linhas, ids, acao),
            Text.literal("Selecione um jogador")));
    }

    private ItemStack cabeca(GameProfile perfil) {
        ItemStack s = new ItemStack(Items.PLAYER_HEAD);
        NbtCompound dono = new NbtCompound();
        NbtHelper.writeGameProfile(dono, perfil);
        s.getOrCreateNbt().put("SkullOwner", dono);
        s.setCustomName(Text.literal(perfil.getName())
            .setStyle(Style.EMPTY.withColor(Formatting.WHITE).withItalic(false)));
        return s;
    }

    private void abrirMenu(ServerPlayerEntity player) {
        SimpleInventory menu = new SimpleInventory(18) {
            @Override
            public boolean isValid(int slot, ItemStack stack) {
                return false;
            }
        };
        menu.setStack(0, criarEspada());
        menu.setStack(1, criarPena());
        menu.setStack(2, criarEscudo());
        menu.setStack(3, criarPocao());
        menu.setStack(4, criarTridente());
        menu.setStack(5, criarPicareta());
        menu.setStack(6, criarCapacete());
        menu.setStack(7, comBrilho(base(Items.DRAGON_HEAD, "Drag\u00e3o Lend\u00e1rio", DRAGAO_ID, 0)));
        menu.setStack(8, comBrilho(base(Items.CLOCK, "Rel\u00f3gio Lend\u00e1rio", RELOGIO_ID, 0)));
        menu.setStack(9, comBrilho(base(Items.SOUL_LANTERN, "Lampi\u00e3o Lend\u00e1rio", LAMPIAO_ID, 0)));
        menu.setStack(10, comBrilho(base(Items.COMPASS, "B\u00fassola Lend\u00e1ria", BUSSOLA_ID, 0)));
        menu.setStack(11, base(Items.POISONOUS_POTATO, "Batata do Bobo", BATATA_ID, 0));
        menu.setStack(12, criarBota());

        Text titulo = Text.literal("CS").formatted(Formatting.GOLD, Formatting.BOLD)
            .append(Text.literal("» ").formatted(Formatting.GRAY))
            .append(Text.literal("Relíquia").formatted(Formatting.DARK_GRAY));

        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (syncId, inv, p) -> new MenuReliquia(syncId, inv, menu, 2), titulo));
    }

    private ItemStack base(Item material, String nome, String id, int flagsExtras) {
        ItemStack stack = new ItemStack(material);
        stack.setCustomName(Text.literal(nome)
            .setStyle(Style.EMPTY.withColor(Formatting.YELLOW)
                .withBold(true).withUnderline(true).withItalic(false)));
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.putBoolean("Unbreakable", true);
        nbt.putInt("HideFlags", 1 | 4 | flagsExtras);
        nbt.putString(TAG, id);
        return stack;
    }

    private ItemStack comBrilho(ItemStack s) {
        s.addEnchantment(Enchantments.UNBREAKING, 1); // só brilho, escondido
        return s;
    }

    private ItemStack criarEspada() {
        ItemStack s = base(Items.GOLDEN_SWORD, "Espada do Caçador", ESPADA_ID, 0);
        s.addEnchantment(Enchantments.KNOCKBACK, 10);
        return s;
    }

    private ItemStack criarPena() {
        return comBrilho(base(Items.FEATHER, "Pena Lendária", PENA_ID, 0));
    }

    private ItemStack criarEscudo() {
        return comBrilho(base(Items.SHIELD, "Escudo Lendário", ESCUDO_ID, 0));
    }

    private ItemStack criarPocao() {
        ItemStack s = base(Items.SPLASH_POTION, "Poção Lendária", POCAO_ID, 32);
        s.getOrCreateNbt().putInt("CustomPotionColor", 16711935);
        PotionUtil.setCustomPotionEffects(s, List.of(new StatusEffectInstance(StatusEffects.BLINDNESS, 800, 0)));
        return s;
    }

    private ItemStack criarTridente() {
        ItemStack s = base(Items.TRIDENT, "Tridente Lendário", TRIDENTE_ID, 0);
        s.addEnchantment(Enchantments.IMPALING, 5);
        s.addEnchantment(Enchantments.LOYALTY, 3);
        s.addEnchantment(Enchantments.CHANNELING, 1);
        s.addEnchantment(Enchantments.UNBREAKING, 3);
        s.addEnchantment(Enchantments.MENDING, 1);
        return s;
    }

    private ItemStack criarPicareta() {
        ItemStack s = base(Items.IRON_PICKAXE, "Picareta Lendária", PICARETA_ID, 0);
        s.addEnchantment(Enchantments.EFFICIENCY, 13);
        return s;
    }

    private ItemStack criarBota() {
        ItemStack s = base(Items.DIAMOND_BOOTS, "Bota Lendária", BOTA_ID, 0);
        s.addEnchantment(Enchantments.PROTECTION, 4);
        s.addEnchantment(Enchantments.FEATHER_FALLING, 4);
        s.addEnchantment(Enchantments.DEPTH_STRIDER, 3);
        s.addEnchantment(Enchantments.SOUL_SPEED, 3);
        s.addEnchantment(Enchantments.THORNS, 3);
        s.addEnchantment(Enchantments.UNBREAKING, 3);
        s.addEnchantment(Enchantments.MENDING, 1);
        return s;
    }

    private ItemStack criarCapacete() {
        ItemStack s = base(Items.TURTLE_HELMET, "Capacete Lendário dos Gêmeos", CAPACETE_ID, 2);
        s.addAttributeModifier(EntityAttributes.GENERIC_MAX_HEALTH,
            new EntityAttributeModifier(UUID.fromString("5d6f0ba2-1384-4879-8f22-2b6a1d1e0a01"),
                "Gemeos vida", 10.0, EntityAttributeModifier.Operation.ADDITION), EquipmentSlot.HEAD);
        s.addAttributeModifier(EntityAttributes.GENERIC_ARMOR,
            new EntityAttributeModifier(UUID.fromString("5d6f0ba2-1384-4879-8f22-2b6a1d1e0a02"),
                "Gemeos armadura", 2.0, EntityAttributeModifier.Operation.ADDITION), EquipmentSlot.HEAD);
        return s;
    }

    public static boolean temId(ItemStack stack, String id) {
        return !stack.isEmpty() && stack.hasNbt() && id.equals(stack.getNbt().getString(TAG));
    }

    public static boolean isReliquia(ItemStack stack) {
        return !stack.isEmpty() && stack.hasNbt() && !stack.getNbt().getString(TAG).isEmpty();
    }
}
