package com.cs.reliquia;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.UUID;
import java.util.function.BiConsumer;

/** Menu "Selecione um jogador": clicar escolhe o jogador; nada pode ser movido (nem no seu inventário). */
public class MenuSelecao extends GenericContainerScreenHandler {

    private final int tamanho;
    private final List<UUID> alvos;
    private final BiConsumer<ServerPlayerEntity, UUID> acao;

    public MenuSelecao(int syncId, PlayerInventory inv, Inventory menu, int linhas,
                       List<UUID> alvos, BiConsumer<ServerPlayerEntity, UUID> acao) {
        super(tipo(linhas), syncId, inv, menu, linhas);
        this.tamanho = linhas * 9;
        this.alvos = alvos;
        this.acao = acao;
    }

    private static ScreenHandlerType<GenericContainerScreenHandler> tipo(int linhas) {
        return switch (linhas) {
            case 1 -> ScreenHandlerType.GENERIC_9X1;
            case 2 -> ScreenHandlerType.GENERIC_9X2;
            case 3 -> ScreenHandlerType.GENERIC_9X3;
            case 4 -> ScreenHandlerType.GENERIC_9X4;
            case 5 -> ScreenHandlerType.GENERIC_9X5;
            default -> ScreenHandlerType.GENERIC_9X6;
        };
    }

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        // Só escolher o jogador; qualquer outro clique (inclusive no inventário) é ignorado
        if (slotIndex >= 0 && slotIndex < tamanho
                && (actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE)
                && slotIndex < alvos.size() && player instanceof ServerPlayerEntity sp) {
            UUID alvo = alvos.get(slotIndex);
            this.syncState();
            sp.closeHandledScreen();
            acao.accept(sp, alvo);
            return;
        }
        this.syncState();
    }
}
