package com.cs.reliquia.mixin;

import com.cs.reliquia.CsReliquia;
import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(EntityEquipmentUpdateS2CPacket.class)
public abstract class EntityEquipmentUpdateS2CPacketMixin {

    @Shadow
    @Final
    @Mutable
    private List<Pair<EquipmentSlot, ItemStack>> equipmentList;

    // Quem segura o Lampião Lendário aparece sem armadura e sem itens para os outros
    @Inject(method = "<init>(ILjava/util/List;)V", at = @At("RETURN"))
    private void cs$ocultar(int id, List<Pair<EquipmentSlot, ItemStack>> lista, CallbackInfo ci) {
        if (CsReliquia.OCULTOS.contains(id)) {
            this.equipmentList = CsReliquia.filtrarEquipamento(lista);
        }
    }
}
