package com.cs.reliquia;

import com.cs.reliquia.mixin.PlayerEntityAccessor;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.LodestoneTrackerComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.EntityTrackerEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntitiesDestroyS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.Unit;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.GlobalPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;

import static net.minecraft.server.command.CommandManager.literal;

public class CsReliquia implements ModInitializer {

    public static final String TAG = "CsItem";
    public static final String ESPADA_ID = "espada_cacador";
    public static final String PENA_ID = "pena_lendaria";
    public static final String ESCUDO_ID = "escudo_lendario";
    public static final String POCAO_ID = "pocao_lendaria";
    public static final String TRIDENTE_ID = "tridente_lendario";
    public static final String PICARETA_ID = "picareta_lendaria";
    public static final String CAPACETE_ID = "capacete_gemeos";
    public static final String DRAGAO_ID = "dragao_area";
    public static final String RELOGIO_ID = "relogio_lendario";
    public static final String LAMPIAO_ID = "lampiao_lendario";
    public static final String BUSSOLA_ID = "bussola_lendaria";
    public static final String BATATA_ID = "batata_do_bobo";
    public static final String BOTA_ID = "bota_lendaria";

    // ---- Rajada do Warden (Escudo) ----
    private static final double ALCANCE = 15.0;
    private static final float DANO = 3.5f;
    private static final double KB_HORIZONTAL = 1.2;
    private static final double KB_VERTICAL = 0.5;
    private static final int COOLDOWN_ESCUDO = 200;   // 10 s
    // ---- Poção ----
    private static final int COOLDOWN_POCAO = 100;    // 5 s
    // ---- Bafo do Dragão ----
    private static final int COOLDOWN_DRAGAO = 200;   // 10 s
    private static final float BAFO_RAIO = 3.0f;
    private static final int BAFO_DURACAO = 100;      // 5 s
    private static final float BAFO_DANO = 4.0f;      // a cada 1 s dentro da nuvem

    private static final Map<UUID, Integer> ULTIMO_ESCUDO = new HashMap<>();
    private static final Map<UUID, Integer> RAIO_MARCADO = new HashMap<>();
    private static final Set<UUID> GEMEOS = new HashSet<>();

    /** IDs de jogadores com equipamento escondido por causa do Lampião. */
    public static final Set<Integer> OCULTOS = ConcurrentHashMap.newKeySet();

    // ---- Skins ----
    private static final Map<UUID, GameProfile> ORIGINAIS = new HashMap<>();
    private static final Map<UUID, Disfarce> DISFARCES = new HashMap<>();

    private static class Disfarce {
        UUID alvo;
        List<Property> textura;
        Disfarce(UUID alvo, List<Property> textura) { this.alvo = alvo; this.textura = textura; }
    }

    private static class Bafo {
        ServerWorld mundo; double x, y, z; UUID dono; int inicio, fim;
    }
    private static final List<Bafo> BAFOS = new ArrayList<>();

    private RegistryWrapper.WrapperLookup lookup;

    public static void marcarRaio(UUID uuid, int tick) {
        RAIO_MARCADO.put(uuid, tick);
    }

    private static ServerWorld mundo(Entity e) {
        return (ServerWorld) e.getWorld();
    }

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(literal("cs4").executes(ctx -> {
                abrirMenu(ctx.getSource().getPlayerOrThrow());
                return 1;
            }))
        );

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity p = handler.player;
            ORIGINAIS.remove(p.getUuid());
            DISFARCES.remove(p.getUuid());
            OCULTOS.remove(p.getId());
            GEMEOS.remove(p.getUuid());
        });

        // "Comando de repetição": roda todo tick no servidor
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int tick = server.getTicks();
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                ItemStack main = player.getMainHandStack();
                ItemStack off = player.getOffHandStack();

                if (temId(main, ESPADA_ID) || temId(off, ESPADA_ID)) {
                    aplicar(player, StatusEffects.BAD_OMEN, 5, 20);
                }
                if (temId(main, PENA_ID) || temId(off, PENA_ID)) {
                    aplicar(player, StatusEffects.LEVITATION, 12, 80);
                }

                // Capacete dos Gêmeos
                if (temId(player.getEquippedStack(EquipmentSlot.HEAD), CAPACETE_ID)) {
                    GEMEOS.add(player.getUuid());
                    aplicar(player, StatusEffects.WATER_BREATHING, 0, 40);
                } else {
                    GEMEOS.remove(player.getUuid());
                }

                // Bota Lendária (vale também depois de virar netherite)
                if (temId(player.getEquippedStack(EquipmentSlot.FEET), BOTA_ID)) {
                    aplicar(player, StatusEffects.SPEED, 4, 80);
                }

                // Lampião Lendário
                boolean lampiao = temId(main, LAMPIAO_ID) || temId(off, LAMPIAO_ID);
                if (lampiao) {
                    aplicar(player, StatusEffects.INVISIBILITY, 12, 20);
                }
                atualizarOcultacao(player, lampiao);

                // Batata do Bobo no inventário
                if (temNoInventario(player, BATATA_ID)) {
                    aplicar(player, StatusEffects.SLOWNESS, 4, 20);
                }

                // Bússola
                if (tick % 10 == 0) {
                    for (int i = 0; i < player.getInventory().size(); i++) {
                        ItemStack s = player.getInventory().getStack(i);
                        if (temId(s, BUSSOLA_ID)) atualizarBussola(s, server);
                    }
                }
            }
            if (tick % 20 == 0) acompanharSkins(server);
            processarBafos(server, tick);
        });

        // Botão direito
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient() || !(player instanceof ServerPlayerEntity sp)) {
                return ActionResult.PASS;
            }

            if (temId(stack, ESCUDO_ID)) {
                int agora = sp.getServer().getTicks();
                Integer ultimo = ULTIMO_ESCUDO.get(sp.getUuid());
                if (ultimo == null || agora - ultimo >= COOLDOWN_ESCUDO) {
                    ULTIMO_ESCUDO.put(sp.getUuid(), agora);
                    soltarRajada(sp);
                }
                return ActionResult.PASS;
            }

            if (temId(stack, POCAO_ID)) {
                if (sp.getItemCooldownManager().isCoolingDown(stack)) {
                    return ActionResult.FAIL;
                }
                lancarPocao(sp, stack);
                return ActionResult.SUCCESS;
            }

            if (temId(stack, DRAGAO_ID)) {
                return dispararBafo(sp, stack) ? ActionResult.SUCCESS : ActionResult.FAIL;
            }

            if (temId(stack, RELOGIO_ID)) {
                abrirSelecao(sp, false, CsReliquia::trocarSkin);
                return ActionResult.SUCCESS;
            }

            if (temId(stack, BUSSOLA_ID)) {
                abrirSelecao(sp, true, (eu, alvo) -> escolherAlvo(eu, alvo, hand));
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });

        // Tridente Lendário na mão
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient() && entity instanceof LivingEntity alvo
                    && temId(player.getStackInHand(hand), TRIDENTE_ID)) {
                alvo.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 200, 2), player);
            }
            return ActionResult.PASS;
        });

        // Mortes
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof ServerPlayerEntity morto)) return;
            MinecraftServer server = morto.getServer();
            OCULTOS.remove(morto.getId());

            Integer marca = RAIO_MARCADO.remove(morto.getUuid());
            if (marca != null && server.getTicks() - marca <= 60) {
                morto.getInventory().clear();
                List<ItemEntity> drops = mundo(morto).getEntitiesByClass(ItemEntity.class,
                    morto.getBoundingBox().expand(4.0), i -> i.getItemAge() <= 5);
                for (ItemEntity drop : drops) drop.discard();
            }

            if (GEMEOS.remove(morto.getUuid())) {
                for (ServerPlayerEntity outro : server.getPlayerManager().getPlayerList()) {
                    if (outro != morto && outro.isAlive() && GEMEOS.contains(outro.getUuid())) {
                        GEMEOS.remove(outro.getUuid());
                        ServerWorld w = mundo(outro);
                        outro.damage(w, w.getDamageSources().outOfWorld(), Float.MAX_VALUE);
                    }
                }
            }
        });
    }

    private static void aplicar(ServerPlayerEntity player, RegistryEntry<StatusEffect> efeito, int amplificador, int duracao) {
        StatusEffectInstance atual = player.getStatusEffect(efeito);
        if (atual == null || atual.getDuration() <= 10 || atual.getAmplifier() != amplificador) {
            player.addStatusEffect(new StatusEffectInstance(efeito, duracao, amplificador, false, false, true));
        }
    }

    private static boolean temNoInventario(ServerPlayerEntity p, String id) {
        for (int i = 0; i < p.getInventory().size(); i++) {
            if (temId(p.getInventory().getStack(i), id)) return true;
        }
        return false;
    }

    // ---------- Poção Lendária ----------
    private void lancarPocao(ServerPlayerEntity player, ItemStack stack) {
        ServerWorld world = mundo(player);

        ItemStack lingering = new ItemStack(Items.LINGERING_POTION);
        lingering.set(DataComponentTypes.POTION_CONTENTS, stack.get(DataComponentTypes.POTION_CONTENTS));

        ProjectileEntity.spawnWithVelocity(PotionEntity::new, world, lingering, player, -20.0F, 0.5F, 1.0F);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_LINGERING_POTION_THROW, SoundCategory.PLAYERS, 0.5F,
            0.4F / (world.getRandom().nextFloat() * 0.4F + 0.8F));

        player.getItemCooldownManager().set(stack, COOLDOWN_POCAO);
        if (!player.getAbilities().creativeMode) stack.decrement(1);
    }

    // ---------- Bafo do Dragão ----------
    public static boolean dispararBafo(ServerPlayerEntity player, ItemStack stack) {
        if (player.getItemCooldownManager().isCoolingDown(stack)) return false;
        ServerWorld world = mundo(player);

        Vec3d inicio = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0f);
        Vec3d fim = inicio.add(dir.multiply(8.0));
        var bloco = world.raycast(new RaycastContext(inicio, fim,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        if (bloco.getType() != HitResult.Type.MISS) {
            fim = bloco.getPos().subtract(dir.multiply(0.3));
        }

        double comp = inicio.distanceTo(fim);
        for (double d = 1.0; d < comp; d += 0.5) {
            Vec3d p = inicio.add(dir.multiply(d));
            world.spawnParticles(ParticleTypes.DRAGON_BREATH, p.x, p.y, p.z, 3, 0.15, 0.15, 0.15, 0.01);
        }

        AreaEffectCloudEntity nuvem = new AreaEffectCloudEntity(world, fim.x, fim.y, fim.z);
        nuvem.setOwner(player);
        nuvem.setParticleType(ParticleTypes.DRAGON_BREATH);
        nuvem.setRadius(BAFO_RAIO);
        nuvem.setDuration(BAFO_DURACAO);
        nuvem.setWaitTime(0);
        world.spawnEntity(nuvem);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_ENDER_DRAGON_SHOOT, SoundCategory.PLAYERS, 1.0f, 1.0f);

        Bafo b = new Bafo();
        b.mundo = world; b.x = fim.x; b.y = fim.y; b.z = fim.z;
        b.dono = player.getUuid();
        b.inicio = player.getServer().getTicks();
        b.fim = b.inicio + BAFO_DURACAO;
        BAFOS.add(b);

        player.getItemCooldownManager().set(stack, COOLDOWN_DRAGAO);
        return true;
    }

    private static void processarBafos(MinecraftServer server, int tick) {
        Iterator<Bafo> it = BAFOS.iterator();
        while (it.hasNext()) {
            Bafo b = it.next();
            if (tick >= b.fim) { it.remove(); continue; }
            if ((tick - b.inicio) % 20 != 0) continue;
            Box caixa = new Box(b.x - BAFO_RAIO, b.y - 1.0, b.z - BAFO_RAIO,
                                b.x + BAFO_RAIO, b.y + 2.0, b.z + BAFO_RAIO);
            for (LivingEntity e : b.mundo.getEntitiesByClass(LivingEntity.class, caixa,
                    x -> x.isAlive() && !x.getUuid().equals(b.dono))) {
                double dx = e.getX() - b.x, dz = e.getZ() - b.z;
                if (dx * dx + dz * dz <= BAFO_RAIO * BAFO_RAIO) {
                    e.damage(b.mundo, b.mundo.getDamageSources().dragonBreath(), BAFO_DANO);
                }
            }
        }
    }

    // ---------- Rajada do Warden ----------
    private void soltarRajada(ServerPlayerEntity player) {
        ServerWorld world = mundo(player);
        Vec3d inicio = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0f);
        Vec3d fim = inicio.add(dir.multiply(ALCANCE));

        var bloco = world.raycast(new RaycastContext(inicio, fim,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        if (bloco.getType() != HitResult.Type.MISS) {
            fim = bloco.getPos();
        }
        double comprimento = inicio.distanceTo(fim);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 3.0f, 1.0f);

        for (int i = 1; i < (int) Math.floor(comprimento); i++) {
            Vec3d p = inicio.add(dir.multiply(i));
            world.spawnParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }

        Box area = new Box(inicio, fim).expand(1.5);
        List<Entity> alvos = world.getOtherEntities(player, area,
            e -> e instanceof LivingEntity && e.isAlive());
        for (Entity e : alvos) {
            if (e.getBoundingBox().expand(0.6).raycast(inicio, fim).isEmpty()) continue;
            LivingEntity alvo = (LivingEntity) e;

            alvo.damage(world, world.getDamageSources().sonicBoom(player), DANO);

            Vec3d horizontal = new Vec3d(dir.x, 0, dir.z);
            horizontal = horizontal.lengthSquared() < 1.0E-4 ? dir : horizontal.normalize();
            alvo.setVelocity(horizontal.x * KB_HORIZONTAL, KB_VERTICAL, horizontal.z * KB_HORIZONTAL);
            alvo.velocityModified = true;
            if (alvo instanceof ServerPlayerEntity alvoPlayer) {
                alvoPlayer.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(alvoPlayer));
            }
        }
    }

    // ---------- Lampião: esconder equipamento ----------
    public static List<Pair<EquipmentSlot, ItemStack>> filtrarEquipamento(List<Pair<EquipmentSlot, ItemStack>> original) {
        List<Pair<EquipmentSlot, ItemStack>> nova = new ArrayList<>();
        for (Pair<EquipmentSlot, ItemStack> par : original) {
            EquipmentSlot slot = par.getFirst();
            ItemStack s = par.getSecond();
            boolean manter = (slot == EquipmentSlot.CHEST && s.isOf(Items.ELYTRA))
                          || (slot == EquipmentSlot.HEAD && s.isOf(Items.CARVED_PUMPKIN));
            nova.add(manter ? par : Pair.of(slot, ItemStack.EMPTY));
        }
        return nova;
    }

    private static EntityEquipmentUpdateS2CPacket pacoteEquipamento(ServerPlayerEntity p) {
        List<Pair<EquipmentSlot, ItemStack>> lista = new ArrayList<>();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            lista.add(Pair.of(slot, p.getEquippedStack(slot)));
        }
        return new EntityEquipmentUpdateS2CPacket(p.getId(), lista);
    }

    private static void enviarEquipamento(ServerPlayerEntity p) {
        EntityEquipmentUpdateS2CPacket pacote = pacoteEquipamento(p);
        for (ServerPlayerEntity v : PlayerLookup.tracking(p)) {
            if (v != p) v.networkHandler.sendPacket(pacote);
        }
    }

    private static void atualizarOcultacao(ServerPlayerEntity p, boolean oculto) {
        boolean ja = OCULTOS.contains(p.getId());
        if (oculto && !ja) {
            OCULTOS.add(p.getId());
            enviarEquipamento(p);
        } else if (!oculto && ja) {
            OCULTOS.remove(p.getId());
            enviarEquipamento(p);
        }
    }

    // ---------- Skins (Relógio Lendário) ----------
    private static GameProfile original(ServerPlayerEntity p) {
        return ORIGINAIS.computeIfAbsent(p.getUuid(), k -> p.getGameProfile());
    }

    private static List<Property> textura(GameProfile perfil) {
        return new ArrayList<>(perfil.getProperties().get("textures"));
    }

    private static void trocarSkin(ServerPlayerEntity eu, UUID alvoUuid) {
        if (alvoUuid.equals(eu.getUuid())) {
            ((PlayerEntityAccessor) eu).cs$setGameProfile(original(eu));
            DISFARCES.remove(eu.getUuid());
            atualizarAparencia(eu);
            return;
        }
        ServerPlayerEntity alvo = eu.getServer().getPlayerManager().getPlayer(alvoUuid);
        if (alvo == null) return;
        aplicarDisfarce(eu, alvo);
    }

    private static void aplicarDisfarce(ServerPlayerEntity eu, ServerPlayerEntity alvo) {
        GameProfile origEu = original(eu);
        GameProfile origAlvo = original(alvo);

        GameProfile falso = new GameProfile(origEu.getId(), origAlvo.getName());
        falso.getProperties().putAll(origAlvo.getProperties());
        ((PlayerEntityAccessor) eu).cs$setGameProfile(falso);

        DISFARCES.put(eu.getUuid(), new Disfarce(alvo.getUuid(), textura(origAlvo)));
        atualizarAparencia(eu);
    }

    /** Se o alvo trocar de skin (por outro mod), quem está usando a skin dele acompanha. */
    private static void acompanharSkins(MinecraftServer server) {
        for (UUID uuid : new ArrayList<>(DISFARCES.keySet())) {
            Disfarce d = DISFARCES.get(uuid);
            ServerPlayerEntity eu = server.getPlayerManager().getPlayer(uuid);
            ServerPlayerEntity alvo = server.getPlayerManager().getPlayer(d.alvo);
            if (eu == null || alvo == null) continue;
            if (!textura(original(alvo)).equals(d.textura)) {
                aplicarDisfarce(eu, alvo);
            }
        }
    }

    private static void atualizarAparencia(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        Set<ServerPlayerEntity> vendo = new HashSet<>(PlayerLookup.tracking(p));
        vendo.remove(p);

        PlayerRemoveS2CPacket remover = new PlayerRemoveS2CPacket(List.of(p.getUuid()));
        PlayerListS2CPacket adicionar = new PlayerListS2CPacket(
            EnumSet.of(PlayerListS2CPacket.Action.ADD_PLAYER,
                       PlayerListS2CPacket.Action.INITIALIZE_CHAT,
                       PlayerListS2CPacket.Action.UPDATE_GAME_MODE,
                       PlayerListS2CPacket.Action.UPDATE_LISTED,
                       PlayerListS2CPacket.Action.UPDATE_LATENCY,
                       PlayerListS2CPacket.Action.UPDATE_DISPLAY_NAME),
            List.of(p));

        // entrada temporária só para reaproveitar o envio de spawn do servidor
        EntityTrackerEntry entrada = new EntityTrackerEntry(mundo(p), p, 1, false, pacote -> { }, (pacote, lista) -> { });

        for (ServerPlayerEntity v : server.getPlayerManager().getPlayerList()) {
            boolean ve = vendo.contains(v);
            if (ve) v.networkHandler.sendPacket(new EntitiesDestroyS2CPacket(p.getId()));
            v.networkHandler.sendPacket(remover);
            v.networkHandler.sendPacket(adicionar);
            if (ve) {
                entrada.sendPackets(v, v.networkHandler::sendPacket);
            }
        }
    }

    // ---------- Bússola Lendária ----------
    private static void escolherAlvo(ServerPlayerEntity eu, UUID alvoUuid, Hand hand) {
        ServerPlayerEntity alvo = eu.getServer().getPlayerManager().getPlayer(alvoUuid);
        if (alvo == null) return;

        ItemStack bussola = eu.getStackInHand(hand);
        if (!temId(bussola, BUSSOLA_ID)) {
            bussola = ItemStack.EMPTY;
            for (int i = 0; i < eu.getInventory().size(); i++) {
                ItemStack s = eu.getInventory().getStack(i);
                if (temId(s, BUSSOLA_ID)) { bussola = s; break; }
            }
        }
        if (bussola.isEmpty()) return;

        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, bussola, nbt -> nbt.putString("CsAlvo", alvoUuid.toString()));
        atualizarBussola(bussola, eu.getServer());

        eu.sendMessage(Text.literal("\u00a7aVoc\u00ea Selecionou o Jogador \u00a7f"
            + original(alvo).getName() + " \u00a7acomo alvo"), false);
    }

    private static void atualizarBussola(ItemStack s, MinecraftServer server) {
        NbtComponent dados = s.get(DataComponentTypes.CUSTOM_DATA);
        String a = dados == null ? "" : dados.copyNbt().getString("CsAlvo");
        ServerPlayerEntity alvo = null;
        if (!a.isEmpty()) {
            try {
                alvo = server.getPlayerManager().getPlayer(UUID.fromString(a));
            } catch (IllegalArgumentException ignored) { }
        }

        if (alvo == null) {
            // alvo saiu: volta a apontar para o ponto de ressurgimento do mundo
            if (s.contains(DataComponentTypes.LODESTONE_TRACKER)) {
                s.remove(DataComponentTypes.LODESTONE_TRACKER);
            }
            return;
        }

        BlockPos pos = alvo.getBlockPos();
        GlobalPos nova = GlobalPos.create(alvo.getWorld().getRegistryKey(), pos);
        LodestoneTrackerComponent atual = s.get(DataComponentTypes.LODESTONE_TRACKER);
        boolean atualizar = atual == null || atual.target().isEmpty()
            || !atual.target().get().dimension().equals(nova.dimension())
            || atual.target().get().pos().getSquaredDistance(pos) >= 4;
        if (atualizar) {
            s.set(DataComponentTypes.LODESTONE_TRACKER, new LodestoneTrackerComponent(Optional.of(nova), false));
        }
    }

    // ---------- Menus ----------
    private void abrirSelecao(ServerPlayerEntity player, boolean excluirEu, BiConsumer<ServerPlayerEntity, UUID> acao) {
        List<ServerPlayerEntity> jogadores = new ArrayList<>(player.getServer().getPlayerManager().getPlayerList());
        if (excluirEu) jogadores.remove(player);

        int linhas = Math.max(1, Math.min(6, (jogadores.size() + 8) / 9));
        SimpleInventory inv = new SimpleInventory(linhas * 9) {
            @Override
            public boolean isValid(int slot, ItemStack stack) {
                return false;
            }
        };
        List<UUID> ids = new ArrayList<>();
        for (int i = 0; i < jogadores.size() && i < linhas * 9; i++) {
            ServerPlayerEntity j = jogadores.get(i);
            inv.setStack(i, cabeca(original(j)));
            ids.add(j.getUuid());
        }

        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (syncId, pinv, p) -> new MenuSelecao(syncId, pinv, inv, linhas, ids, acao),
            Text.literal("Selecione um jogador")));
    }

    private ItemStack cabeca(GameProfile perfil) {
        ItemStack s = new ItemStack(Items.PLAYER_HEAD);
        s.set(DataComponentTypes.PROFILE, new ProfileComponent(perfil));
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal(perfil.getName())
            .setStyle(Style.EMPTY.withColor(Formatting.WHITE).withItalic(false)));
        return s;
    }

    private void abrirMenu(ServerPlayerEntity player) {
        lookup = player.getServer().getRegistryManager();

        SimpleInventory menu = new SimpleInventory(18) {
            @Override
            public boolean isValid(int slot, ItemStack stack) {
                return false;
            }
        };
        menu.setStack(0, criarEspada());
        menu.setStack(1, comBrilho(base(Items.FEATHER, "Pena Lend\u00e1ria", PENA_ID)));
        menu.setStack(2, comBrilho(base(Items.SHIELD, "Escudo Lend\u00e1rio", ESCUDO_ID)));
        menu.setStack(3, criarPocao());
        menu.setStack(4, criarTridente());
        menu.setStack(5, criarPicareta());
        menu.setStack(6, criarCapacete());
        menu.setStack(7, comBrilho(base(Items.DRAGON_HEAD, "Drag\u00e3o Lend\u00e1rio", DRAGAO_ID)));
        menu.setStack(8, comBrilho(base(Items.CLOCK, "Rel\u00f3gio Lend\u00e1rio", RELOGIO_ID)));
        menu.setStack(9, comBrilho(base(Items.SOUL_LANTERN, "Lampi\u00e3o Lend\u00e1rio", LAMPIAO_ID)));
        menu.setStack(10, comBrilho(base(Items.COMPASS, "B\u00fassola Lend\u00e1ria", BUSSOLA_ID)));
        menu.setStack(11, base(Items.POISONOUS_POTATO, "Batata do Bobo", BATATA_ID));
        menu.setStack(12, criarBota());

        Text titulo = Text.literal("CS").formatted(Formatting.GOLD, Formatting.BOLD)
            .append(Text.literal("\u00bb ").formatted(Formatting.GRAY))
            .append(Text.literal("Rel\u00edquia").formatted(Formatting.DARK_GRAY));

        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (syncId, inv, p) -> new MenuReliquia(syncId, inv, menu, 2), titulo));
    }

    private ItemStack base(Item material, String nome, String id) {
        ItemStack stack = new ItemStack(material);
        stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal(nome)
            .setStyle(Style.EMPTY.withColor(Formatting.YELLOW)
                .withBold(true).withUnderline(true).withItalic(false)));
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(false)); // inquebrável, sem aparecer
        NbtCompound nbt = new NbtCompound();
        nbt.putString(TAG, id);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        return stack;
    }

    /** Só o brilho de encantado, sem encantamento nenhum. */
    private ItemStack comBrilho(ItemStack s) {
        s.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        return s;
    }

    private void encantar(ItemStack s, RegistryKey<Enchantment> chave, int nivel) {
        RegistryEntry<Enchantment> e = lookup.getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(chave);
        s.addEnchantment(e, nivel);
    }

    private ItemStack esconderEncantos(ItemStack s) {
        ItemEnchantmentsComponent c = s.get(DataComponentTypes.ENCHANTMENTS);
        if (c != null) s.set(DataComponentTypes.ENCHANTMENTS, c.withShowInTooltip(false));
        return s;
    }

    private ItemStack criarEspada() {
        ItemStack s = base(Items.GOLDEN_SWORD, "Espada do Ca\u00e7ador", ESPADA_ID);
        encantar(s, Enchantments.KNOCKBACK, 10);
        return esconderEncantos(s);
    }

    private ItemStack criarPocao() {
        ItemStack s = base(Items.SPLASH_POTION, "Po\u00e7\u00e3o Lend\u00e1ria", POCAO_ID);
        // Cor 16711935 (magenta). A nuvem aplica 1/4 da duração: 800 ticks -> 10 s de cegueira
        s.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(
            Optional.empty(), Optional.of(16711935),
            List.of(new StatusEffectInstance(StatusEffects.BLINDNESS, 800, 0)), Optional.empty()));
        s.set(DataComponentTypes.HIDE_ADDITIONAL_TOOLTIP, Unit.INSTANCE);
        return s;
    }

    private ItemStack criarTridente() {
        ItemStack s = base(Items.TRIDENT, "Tridente Lend\u00e1rio", TRIDENTE_ID);
        encantar(s, Enchantments.IMPALING, 5);
        encantar(s, Enchantments.LOYALTY, 3);
        encantar(s, Enchantments.CHANNELING, 1);
        encantar(s, Enchantments.UNBREAKING, 3);
        encantar(s, Enchantments.MENDING, 1);
        return esconderEncantos(s);
    }

    private ItemStack criarPicareta() {
        ItemStack s = base(Items.IRON_PICKAXE, "Picareta Lend\u00e1ria", PICARETA_ID);
        encantar(s, Enchantments.EFFICIENCY, 13);
        return esconderEncantos(s);
    }

    private ItemStack criarBota() {
        ItemStack s = base(Items.DIAMOND_BOOTS, "Bota Lend\u00e1ria", BOTA_ID);
        encantar(s, Enchantments.PROTECTION, 4);
        encantar(s, Enchantments.FEATHER_FALLING, 4);
        encantar(s, Enchantments.DEPTH_STRIDER, 3);
        encantar(s, Enchantments.SOUL_SPEED, 3);
        encantar(s, Enchantments.THORNS, 3);
        encantar(s, Enchantments.UNBREAKING, 3);
        encantar(s, Enchantments.MENDING, 1);
        return esconderEncantos(s);
    }

    private ItemStack criarCapacete() {
        ItemStack s = base(Items.TURTLE_HELMET, "Capacete Lend\u00e1rio dos G\u00eameos", CAPACETE_ID);
        // +5 cora\u00e7\u00f5es (10 de vida) e mant\u00e9m a armadura original
        s.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.builder()
            .add(EntityAttributes.MAX_HEALTH,
                new EntityAttributeModifier(Identifier.of("csreliquia", "gemeos_vida"), 10.0,
                    EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.HEAD)
            .add(EntityAttributes.ARMOR,
                new EntityAttributeModifier(Identifier.of("csreliquia", "gemeos_armadura"), 2.0,
                    EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.HEAD)
            .build().withShowInTooltip(false));
        return s;
    }

    // ---------- Identifica\u00e7\u00e3o dos itens ----------
    public static String idDe(ItemStack stack) {
        if (stack.isEmpty()) return "";
        NbtComponent c = stack.get(DataComponentTypes.CUSTOM_DATA);
        return c == null ? "" : c.copyNbt().getString(TAG);
    }

    public static boolean temId(ItemStack stack, String id) {
        return id.equals(idDe(stack));
    }

    public static boolean isReliquia(ItemStack stack) {
        return !idDe(stack).isEmpty();
    }
}
