package com.cs.reliquia.mixin;

import com.cs.reliquia.CsReliquia;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    // O Escudo Lendário não defende
    @Inject(method = "isBlocking", at = @At("HEAD"), cancellable = true)
    private void cs$semDefesa(CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (CsReliquia.temId(self.getActiveItem(), CsReliquia.ESCUDO_ID)) {
            cir.setReturnValue(false);
        }
    }
}
