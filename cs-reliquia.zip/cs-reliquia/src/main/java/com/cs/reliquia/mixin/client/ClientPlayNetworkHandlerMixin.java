package com.cs.reliquia.mixin.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * O jogador local guarda a entrada da lista de jogadores em cache. Quando o relógio troca a skin,
 * limpamos esse cache para a SUA skin (na sua visão) mudar também.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {

    @Inject(method = "onPlayerList", at = @At("TAIL"))
    private void cs$listaAtualizada(PlayerListS2CPacket packet, CallbackInfo ci) {
        cs$limpar();
    }

    @Inject(method = "onPlayerRemove", at = @At("TAIL"))
    private void cs$removido(PlayerRemoveS2CPacket packet, CallbackInfo ci) {
        cs$limpar();
    }

    @Unique
    private static void cs$limpar() {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) {
                ((AbstractClientPlayerEntityAccessor) mc.player).cs$setPlayerListEntry(null);
            }
        } catch (Throwable ignored) {
        }
    }
}
