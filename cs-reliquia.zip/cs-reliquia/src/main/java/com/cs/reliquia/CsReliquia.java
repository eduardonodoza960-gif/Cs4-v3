package com.cs.reliquia;

import com.cs.reliquia.mixin.PlayerEntityAccessor;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.LodestoneTrackerComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.component.type.UseCooldownComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.EntityTrackerEntry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.projectile.DragonFireballEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntitiesDestroyS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.Unit;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.GlobalPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.RaycastContext;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;

import static net.minecraft.server.command.CommandManager.literal;

public class CsReliquia implements ModInitializer {

    private static final Logger LOG = LoggerFactory.getLogger("csreliquia");

    public static final String TAG = "CsItem";
    public static final String ESPADA_ID = "espada_cacador";
    public static final String PENA_ID = "pena_lendaria";
    public static final String ESCUDO_ID = "escudo_lendario";
    public static final String POCAO_ID = "pocao_lendaria";
    public static final String TRIDENTE_ID = "tridente_lendario";
    public static final String PICARETA_ID = "picareta_lendaria";
    public static final String CAPACETE_ID = "capacete_gemeos";
    public static final String DRAGAO_ID = "dragao_area";
    public static final String RELOGIO_ID = "relogio_lendario";
    public static final String LAMPIAO_ID = "lampiao_lendario";
    public static final String BUSSOLA_ID = "bussola_lendaria";
    public static final String BATATA_ID = "batata_do_bobo";
    public static final String BOTA_ID = "bota_lendaria";

    // ---- Rajada do Warden (Escudo) ----
    private static final double ALCANCE = 15.0;
    private static final float DANO = 5.5f;           // pontos de vida (5,5 = 2,75 corações)
    private static final double KB_HORIZONTAL = 1.2;
    private static final double KB_VERTICAL = 0.5;
    private static final double DESCIDA = 0.18;       // inclinação para baixo da rajada (linha reta)
    private static final int COOLDOWN_ESCUDO = 200;   // 10 s
    // ---- Poção ----
    private static final int COOLDOWN_POCAO = 100;    // 5 s
    // ---- Bafo do Dragão ----
    private static final int COOLDOWN_DRAGAO = 200;   // 10 s

    private static final Map<UUID, Integer> ULTIMO_ESCUDO = new HashMap<>();
    private static final Map<UUID, Integer> RAIO_MARCADO = new HashMap<>();
    private static final Set<UUID> GEMEOS = new HashSet<>();

    /** IDs de jogadores com equipamento escondido por causa do Lampião. */
    public static final Set<Integer> OCULTOS = ConcurrentHashMap.newKeySet();

    // ---- Skins ----
    private static final Map<UUID, GameProfile> ORIGINAIS = new HashMap<>();
    private static final Map<UUID, Disfarce> DISFARCES = new HashMap<>();

    private static class Disfarce {
        UUID alvo;
        List<Property> textura;
        Disfarce(UUID alvo, List<Property> textura) { this.alvo = alvo; this.textura = textura; }
    }

    private static class Lancada {
        PotionEntity entidade; Vec3d pos; UUID dono; ServerWorld mundo;
    }
    private static final List<Lancada> LANCADAS = new ArrayList<>();
    private static final List<AreaEffectCloudEntity> NUVENS = new ArrayList<>();

    private RegistryWrapper.WrapperLookup lookup;

    public static void marcarRaio(UUID uuid, int tick) {
        RAIO_MARCADO.put(uuid, tick);
    }

    private static ServerWorld mundo(Entity e) {
        return (ServerWorld) e.getWorld();
    }

    @Override
    public void onInitialize() {
        LOG.info("CS Rel\u00edquia carregado (Minecraft 1.21.4)");
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(literal("cs4").executes(ctx -> {
                ServerPlayerEntity jogador = ctx.getSource().getPlayerOrThrow();
                try {
                    abrirMenu(jogador);
                    LOG.info("/cs4 usado por {}", jogador.getGameProfile().getName());
                } catch (Exception e) {
                    LOG.error("Erro ao abrir o menu /cs4", e);
                    jogador.sendMessage(Text.literal("\u00a7cErro ao abrir o menu. Veja o log do servidor."), false);
                }
                return 1;
            }))
        );

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity p = handler.player;
            ORIGINAIS.remove(p.getUuid());
            DISFARCES.remove(p.getUuid());
            OCULTOS.remove(p.getId());
            GEMEOS.remove(p.getUuid());
        });

        // "Comando de repetição": roda todo tick no servidor
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int tick = server.getTicks();
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                ItemStack main = player.getMainHandStack();
                ItemStack off = player.getOffHandStack();

                if (temId(main, ESPADA_ID) || temId(off, ESPADA_ID)) {
                    aplicar(player, StatusEffects.BAD_OMEN, 5, 20);
                }
                if (temId(main, PENA_ID) || temId(off, PENA_ID)) {
                    aplicar(player, StatusEffects.LEVITATION, 12, 80);
                }

                // Capacete dos Gêmeos
                if (temId(player.getEquippedStack(EquipmentSlot.HEAD), CAPACETE_ID)) {
                    GEMEOS.add(player.getUuid());
                    aplicar(player, StatusEffects.WATER_BREATHING, 0, 200);
                } else {
                    GEMEOS.remove(player.getUuid());
                }

                // Bota Lendária (vale também depois de virar netherite)
                if (temId(player.getEquippedStack(EquipmentSlot.FEET), BOTA_ID)) {
                    aplicar(player, StatusEffects.SPEED, 4, 80);
                }

                // Lampião Lendário
                boolean lampiao = temId(main, LAMPIAO_ID) || temId(off, LAMPIAO_ID);
                if (lampiao) {
                    aplicar(player, StatusEffects.INVISIBILITY, 12, 20);
                }
                atualizarOcultacao(player, lampiao);

                // Batata do Bobo no inventário
                if (temNoInventario(player, BATATA_ID)) {
                    aplicar(player, StatusEffects.SLOWNESS, 4, 20);
                }

                // Bússola
                if (tick % 10 == 0) {
                    for (int i = 0; i < player.getInventory().size(); i++) {
                        ItemStack s = player.getInventory().getStack(i);
                        if (temId(s, BUSSOLA_ID)) atualizarBussola(s, server);
                    }
                }
            }
            if (tick % 20 == 0) acompanharSkins(server);
            processarPocoes(tick);
        });

        // Botão direito
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient()) {
                // no cliente: faz a animação de bater (e não levanta o escudo)
                // recarga medida em tempo real, sem depender do relógio de ticks do jogo
                String idc = idDe(stack);
                if (idc.equals(ESCUDO_ID)) return clienteUsar(idc, COOLDOWN_ESCUDO);
                if (idc.equals(POCAO_ID)) return clienteUsar(idc, COOLDOWN_POCAO);
                if (idc.equals(DRAGAO_ID)) return clienteUsar(idc, COOLDOWN_DRAGAO);
                if (idc.equals(RELOGIO_ID) || idc.equals(BUSSOLA_ID)) return ActionResult.SUCCESS; // animação de bater
                return ActionResult.PASS;
            }
            if (!(player instanceof ServerPlayerEntity sp)) {
                return ActionResult.PASS;
            }

            if (temId(stack, ESCUDO_ID)) {
                if (emRecarga(sp, ESCUDO_ID, COOLDOWN_ESCUDO)) {
                    return ActionResult.FAIL;
                }
                soltarRajada(sp);
                sp.getItemCooldownManager().set(stack, COOLDOWN_ESCUDO); // círculo de recarga (10 s)
                marcarUso(sp, ESCUDO_ID);
                sp.swingHand(hand, true);                                // animação de bater
                return ActionResult.SUCCESS;
            }

            if (temId(stack, POCAO_ID)) {
                if (emRecarga(sp, POCAO_ID, COOLDOWN_POCAO)) {
                    return ActionResult.FAIL;
                }
                lancarPocao(sp, stack);
                sp.swingHand(hand, true);
                sp.currentScreenHandler.syncState(); // devolve a poção ao inventário (não gasta)
                return ActionResult.SUCCESS;
            }

            if (temId(stack, DRAGAO_ID)) {
                return dispararBafo(sp, stack) ? ActionResult.SUCCESS : ActionResult.FAIL;
            }

            if (temId(stack, RELOGIO_ID)) {
                abrirSelecao(sp, false, CsReliquia::trocarSkin);
                sp.swingHand(hand, true);
                return ActionResult.SUCCESS;
            }

            if (temId(stack, BUSSOLA_ID)) {
                abrirSelecao(sp, true, (eu, alvo) -> escolherAlvo(eu, alvo, hand));
                sp.swingHand(hand, true);
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });

        // Mortes
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof ServerPlayerEntity morto)) return;
            MinecraftServer server = morto.getServer();
            OCULTOS.remove(morto.getId());

            Integer marca = RAIO_MARCADO.remove(morto.getUuid());
            if (marca != null && server.getTicks() - marca <= 60) {
                // tudo queima (até netherite), menos as relíquias, que não queimam
                for (int i = 0; i < morto.getInventory().size(); i++) {
                    ItemStack st = morto.getInventory().getStack(i);
                    if (!st.isEmpty() && !isReliquia(st)) morto.getInventory().setStack(i, ItemStack.EMPTY);
                }
                List<ItemEntity> drops = mundo(morto).getEntitiesByClass(ItemEntity.class,
                    morto.getBoundingBox().expand(4.0), i -> i.getItemAge() <= 5);
                for (ItemEntity drop : drops) {
                    if (!isReliquia(drop.getStack())) drop.discard();
                }
            }

            if (GEMEOS.remove(morto.getUuid())) {
                for (ServerPlayerEntity outro : server.getPlayerManager().getPlayerList()) {
                    if (outro != morto && outro.isAlive() && GEMEOS.contains(outro.getUuid())) {
                        GEMEOS.remove(outro.getUuid());
                        ServerWorld w = mundo(outro);
                        outro.damage(w, w.getDamageSources().outOfWorld(), Float.MAX_VALUE);
                    }
                }
            }
        });
    }

    // Recarga medida em tempo real: não atrasa se o servidor estiver com TPS baixo
    private static final Map<String, Long> USOS = new HashMap<>();

    private static final Map<String, Long> USOS_CLIENTE = new HashMap<>();

    private static ActionResult clienteUsar(String id, int ticks) {
        long agora = System.currentTimeMillis();
        Long ultimo = USOS_CLIENTE.get(id);
        if (ultimo != null && agora - ultimo < ticks * 50L - 300L) return ActionResult.FAIL;
        USOS_CLIENTE.put(id, agora);
        return ActionResult.SUCCESS;
    }

    private static boolean emRecarga(ServerPlayerEntity p, String id, int ticks) {
        Long ultimo = USOS.get(p.getUuid() + ":" + id);
        if (ultimo == null) return false;
        return System.currentTimeMillis() - ultimo < ticks * 50L - 600L;
    }

    private static void marcarUso(ServerPlayerEntity p, String id) {
        USOS.put(p.getUuid() + ":" + id, System.currentTimeMillis());
    }

    private static void aplicar(ServerPlayerEntity player, RegistryEntry<StatusEffect> efeito, int amplificador, int duracao) {
        StatusEffectInstance atual = player.getStatusEffect(efeito);
        if (atual == null || atual.getDuration() < duracao || atual.getAmplifier() != amplificador) {
            player.addStatusEffect(new StatusEffectInstance(efeito, duracao, amplificador, false, false, true));
        }
    }

    private static boolean temNoInventario(ServerPlayerEntity p, String id) {
        for (int i = 0; i < p.getInventory().size(); i++) {
            if (temId(p.getInventory().getStack(i), id)) return true;
        }
        return false;
    }

    // ---------- Poção Lendária ----------
    private void lancarPocao(ServerPlayerEntity player, ItemStack stack) {
        ServerWorld world = mundo(player);

        ItemStack lingering = new ItemStack(Items.LINGERING_POTION);
        lingering.set(DataComponentTypes.POTION_CONTENTS, stack.get(DataComponentTypes.POTION_CONTENTS));

        PotionEntity entidade = ProjectileEntity.spawnWithVelocity(
            PotionEntity::new, world, lingering, player, -20.0F, 0.5F, 1.0F);

        Lancada l = new Lancada();
        l.entidade = entidade; l.pos = entidade.getPos(); l.dono = player.getUuid(); l.mundo = world;
        LANCADAS.add(l);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_LINGERING_POTION_THROW, SoundCategory.PLAYERS, 0.5F,
            0.4F / (world.getRandom().nextFloat() * 0.4F + 0.8F));

        // a poção volta sozinha (não gasta) e fica 5 s recarregando
        player.getItemCooldownManager().set(stack, COOLDOWN_POCAO);
        marcarUso(player, POCAO_ID);
    }

    /** Acha a nuvem criada pela poção e aplica cegueira de exatos 10 s em quem está dentro. */
    private static void processarPocoes(int tick) {
        Iterator<Lancada> it = LANCADAS.iterator();
        while (it.hasNext()) {
            Lancada l = it.next();
            if (l.entidade.isRemoved()) {
                Box caixa = new Box(l.pos, l.pos).expand(4.0);
                for (AreaEffectCloudEntity c : l.mundo.getEntitiesByClass(AreaEffectCloudEntity.class, caixa, c -> c.age <= 5)) {
                    LivingEntity dono = c.getOwner();
                    if (dono != null && dono.getUuid().equals(l.dono) && !NUVENS.contains(c)) {
                        NUVENS.add(c);
                    }
                }
                it.remove();
            } else {
                l.pos = l.entidade.getPos();
            }
        }

        NUVENS.removeIf(c -> c.isRemoved());
        for (AreaEffectCloudEntity c : NUVENS) {
            float r = c.getRadius();
            if (r < 0.5f) continue;
            ServerWorld w = (ServerWorld) c.getWorld();
            Box caixa = c.getBoundingBox(); // volume real da fumaça: quem está embaixo dela não pega
            for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, caixa, x -> x.isAlive())) {
                double dx = e.getX() - c.getX(), dz = e.getZ() - c.getZ();
                if (dx * dx + dz * dz > r * r) continue;
                StatusEffectInstance atual = e.getStatusEffect(StatusEffects.BLINDNESS);
                if (atual == null || atual.getDuration() < 200) {
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 200, 0, false, true, true));
                }
            }
        }
    }

    // ---------- Dragão Lendário: bola de fogo do Dragão do Fim ----------
    public static boolean dispararBafo(ServerPlayerEntity player, ItemStack stack) {
        if (emRecarga(player, DRAGAO_ID, COOLDOWN_DRAGAO)) return false;
        ServerWorld world = mundo(player);

        Vec3d dir = player.getRotationVec(1.0f);
        Vec3d pos = player.getEyePos().add(dir.multiply(1.0));

        DragonFireballEntity bola = EntityType.DRAGON_FIREBALL.create(world, SpawnReason.TRIGGERED);
        if (bola == null) return false;
        bola.refreshPositionAndAngles(pos.x, pos.y, pos.z, player.getYaw(), player.getPitch());
        bola.setOwner(player);
        bola.setVelocity(dir.multiply(1.0)); // velocidade normal da bola do dragão
        world.spawnEntity(bola);

        player.getItemCooldownManager().set(stack, COOLDOWN_DRAGAO);
        marcarUso(player, DRAGAO_ID);
        return true;
    }

    // ---------- Rajada do Warden ----------
    private void soltarRajada(ServerPlayerEntity player) {
        ServerWorld world = mundo(player);
        Vec3d olhar = player.getRotationVec(1.0f);
        Vec3d olho = player.getEyePos(); // altura da cabeça

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 3.0f, 1.0f);

        // 15 partículas, uma por bloco, em linha reta descendo (atravessa paredes)
        for (int i = 1; i <= 15; i++) {
            Vec3d p = pontoDaRajada(olho, olhar, i);
            world.spawnParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }

        // quem estiver perto de qualquer ponto da linha é atingido (pontaria tolerante)
        Box area = new Box(olho, pontoDaRajada(olho, olhar, ALCANCE)).expand(4.0);
        List<Entity> alvos = world.getOtherEntities(player, area,
            e -> e instanceof LivingEntity && e.isAlive());
        for (Entity e : alvos) {
            Box caixa = e.getBoundingBox().expand(1.5);
            boolean acertou = false;
            for (double d = 0.5; d <= ALCANCE; d += 0.5) {
                if (caixa.contains(pontoDaRajada(olho, olhar, d))) { acertou = true; break; }
            }
            if (!acertou) continue;
            LivingEntity alvo = (LivingEntity) e;

            // Dano por dificuldade. Em jogadores o próprio jogo ainda escala o dano do Sonic Boom
            // (difícil x1,5; fácil metade+1; pacífico 0), então o valor base é compensado.
            Difficulty dif = world.getDifficulty();
            float dano;
            if (alvo instanceof PlayerEntity) {
                dano = switch (dif) {
                    case HARD -> 5.0f;    // vira 7,5
                    case NORMAL -> 5.5f;  // fica 5,5
                    case EASY -> 5.0f;    // vira 3,5
                    default -> 3.5f;      // pacífico: o jogo zera o dano em jogadores
                };
            } else {
                dano = switch (dif) {
                    case HARD -> 7.5f;
                    case NORMAL -> 5.5f;
                    default -> 3.5f;      // fácil e pacífico
                };
            }
            alvo.damage(world, world.getDamageSources().sonicBoom(player), dano);

            Vec3d horizontal = new Vec3d(olhar.x, 0, olhar.z);
            horizontal = horizontal.lengthSquared() < 1.0E-4 ? olhar : horizontal.normalize();
            alvo.setVelocity(horizontal.x * KB_HORIZONTAL, KB_VERTICAL, horizontal.z * KB_HORIZONTAL);
            alvo.velocityModified = true;
            if (alvo instanceof ServerPlayerEntity alvoPlayer) {
                alvoPlayer.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(alvoPlayer));
            }
        }
    }

    /** Ponto da rajada a d blocos: sai da altura da cabeça e segue em linha reta descendo. */
    private static Vec3d pontoDaRajada(Vec3d olho, Vec3d olhar, double d) {
        Vec3d dir = new Vec3d(olhar.x, olhar.y - DESCIDA, olhar.z).normalize();
        return olho.add(dir.multiply(d));
    }

    // ---------- Lampião: esconder equipamento ----------
    public static List<Pair<EquipmentSlot, ItemStack>> filtrarEquipamento(List<Pair<EquipmentSlot, ItemStack>> original) {
        List<Pair<EquipmentSlot, ItemStack>> nova = new ArrayList<>();
        for (Pair<EquipmentSlot, ItemStack> par : original) {
            EquipmentSlot slot = par.getFirst();
            ItemStack s = par.getSecond();
            boolean manter = (slot == EquipmentSlot.CHEST && s.isOf(Items.ELYTRA))
                          || (slot == EquipmentSlot.HEAD && s.isOf(Items.CARVED_PUMPKIN));
            nova.add(manter ? par : Pair.of(slot, ItemStack.EMPTY));
        }
        return nova;
    }

    private static EntityEquipmentUpdateS2CPacket pacoteEquipamento(ServerPlayerEntity p) {
        List<Pair<EquipmentSlot, ItemStack>> lista = new ArrayList<>();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            lista.add(Pair.of(slot, p.getEquippedStack(slot)));
        }
        return new EntityEquipmentUpdateS2CPacket(p.getId(), lista);
    }

    private static void enviarEquipamento(ServerPlayerEntity p) {
        EntityEquipmentUpdateS2CPacket pacote = pacoteEquipamento(p);
        for (ServerPlayerEntity v : PlayerLookup.tracking(p)) {
            if (v != p) v.networkHandler.sendPacket(pacote);
        }
    }

    private static void atualizarOcultacao(ServerPlayerEntity p, boolean oculto) {
        boolean ja = OCULTOS.contains(p.getId());
        if (oculto && !ja) {
            OCULTOS.add(p.getId());
            enviarEquipamento(p);
        } else if (!oculto && ja) {
            OCULTOS.remove(p.getId());
            enviarEquipamento(p);
        }
    }

    // ---------- Skins (Relógio Lendário) ----------
    private static GameProfile original(ServerPlayerEntity p) {
        if (!DISFARCES.containsKey(p.getUuid())) {
            GameProfile vivo = p.getGameProfile(); // acompanha plugins de skin (servidor pirata ou original)
            ORIGINAIS.put(p.getUuid(), vivo);
            return vivo;
        }
        return ORIGINAIS.computeIfAbsent(p.getUuid(), k -> p.getGameProfile());
    }

    private static List<Property> textura(GameProfile perfil) {
        return new ArrayList<>(perfil.getProperties().get("textures"));
    }

    private static void trocarSkin(ServerPlayerEntity eu, UUID alvoUuid) {
        if (alvoUuid.equals(eu.getUuid())) {
            restaurar(eu);
            return;
        }
        ServerPlayerEntity alvo = eu.getServer().getPlayerManager().getPlayer(alvoUuid);
        if (alvo == null) return;
        aplicarDisfarce(eu, alvo);
    }

    private static final Map<String, List<Property>> CACHE_SKINS = new ConcurrentHashMap<>();
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    private static void restaurar(ServerPlayerEntity eu) {
        ((PlayerEntityAccessor) eu).cs$setGameProfile(original(eu));
        DISFARCES.remove(eu.getUuid());
        atualizarAparencia(eu);
    }

    private static void aplicarDisfarce(ServerPlayerEntity eu, ServerPlayerEntity alvo) {
        GameProfile origAlvo = original(alvo);
        List<Property> tex = textura(origAlvo);
        if (!tex.isEmpty()) {
            // original, ou servidor com plugin/mod de skin: copia a skin que o alvo está usando
            efetivarDisfarce(eu, alvo.getUuid(), origAlvo.getName(), tex);
            return;
        }
        // pirata sem skin no perfil: busca a skin oficial pelo nome
        MinecraftServer server = eu.getServer();
        UUID euUuid = eu.getUuid();
        UUID alvoUuid = alvo.getUuid();
        String nomeAlvo = origAlvo.getName();
        buscarSkinMojang(nomeAlvo, lista -> server.execute(() -> {
            ServerPlayerEntity e = server.getPlayerManager().getPlayer(euUuid);
            if (e != null) efetivarDisfarce(e, alvoUuid, nomeAlvo, lista);
        }));
    }

    private static void efetivarDisfarce(ServerPlayerEntity eu, UUID alvoUuid, String nome, List<Property> texturas) {
        GameProfile origEu = original(eu);
        GameProfile falso = new GameProfile(origEu.getId(), nome);
        falso.getProperties().putAll("textures", texturas);
        ((PlayerEntityAccessor) eu).cs$setGameProfile(falso);

        DISFARCES.put(eu.getUuid(), new Disfarce(alvoUuid, texturas));
        atualizarAparencia(eu);
    }

    private static void buscarSkinMojang(String nome, java.util.function.Consumer<List<Property>> depois) {
        String chave = nome.toLowerCase();
        List<Property> guardada = CACHE_SKINS.get(chave);
        if (guardada != null) {
            depois.accept(guardada);
            return;
        }
        Thread t = new Thread(() -> {
            List<Property> resultado = new ArrayList<>();
            try {
                String url1 = "https://api.mojang.com/users/profiles/minecraft/"
                    + URLEncoder.encode(nome, StandardCharsets.UTF_8);
                HttpResponse<String> r1 = HTTP.send(HttpRequest.newBuilder(URI.create(url1))
                    .timeout(Duration.ofSeconds(8)).build(), HttpResponse.BodyHandlers.ofString());
                if (r1.statusCode() == 200) {
                    String id = JsonParser.parseString(r1.body()).getAsJsonObject().get("id").getAsString();
                    String url2 = "https://sessionserver.mojang.com/session/minecraft/profile/" + id + "?unsigned=false";
                    HttpResponse<String> r2 = HTTP.send(HttpRequest.newBuilder(URI.create(url2))
                        .timeout(Duration.ofSeconds(8)).build(), HttpResponse.BodyHandlers.ofString());
                    if (r2.statusCode() == 200) {
                        JsonArray props = JsonParser.parseString(r2.body()).getAsJsonObject().getAsJsonArray("properties");
                        for (JsonElement el : props) {
                            JsonObject o = el.getAsJsonObject();
                            if ("textures".equals(o.get("name").getAsString())) {
                                String assinatura = o.has("signature") ? o.get("signature").getAsString() : null;
                                resultado.add(new Property("textures", o.get("value").getAsString(), assinatura));
                            }
                        }
                    }
                }
            } catch (Exception ignored) { }
            if (!resultado.isEmpty()) CACHE_SKINS.put(chave, resultado);
            depois.accept(resultado);
        }, "cs-reliquia-skin");
        t.setDaemon(true);
        t.start();
    }

    /** Se o alvo trocar de skin (plugin/mod de skin), quem está usando a skin dele acompanha. */
    private static void acompanharSkins(MinecraftServer server) {
        for (UUID uuid : new ArrayList<>(DISFARCES.keySet())) {
            Disfarce d = DISFARCES.get(uuid);
            ServerPlayerEntity eu = server.getPlayerManager().getPlayer(uuid);
            ServerPlayerEntity alvo = server.getPlayerManager().getPlayer(d.alvo);
            if (eu == null) { DISFARCES.remove(uuid); continue; }
            if (alvo == null) { restaurar(eu); continue; } // o jogador copiado saiu: volta a sua skin
            List<Property> atual = textura(original(alvo));
            if (atual.isEmpty()) continue; // alvo pirata sem skin no perfil: nada para acompanhar
            if (!atual.equals(d.textura)) {
                aplicarDisfarce(eu, alvo);
            }
        }
    }

    private static void atualizarAparencia(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        Set<ServerPlayerEntity> vendo = new HashSet<>(PlayerLookup.tracking(p));
        vendo.remove(p);

        PlayerRemoveS2CPacket remover = new PlayerRemoveS2CPacket(List.of(p.getUuid()));
        PlayerListS2CPacket adicionar = new PlayerListS2CPacket(
            EnumSet.of(PlayerListS2CPacket.Action.ADD_PLAYER,
                       PlayerListS2CPacket.Action.INITIALIZE_CHAT,
                       PlayerListS2CPacket.Action.UPDATE_GAME_MODE,
                       PlayerListS2CPacket.Action.UPDATE_LISTED,
                       PlayerListS2CPacket.Action.UPDATE_LATENCY,
                       PlayerListS2CPacket.Action.UPDATE_DISPLAY_NAME),
            List.of(p));

        // entrada temporária só para reaproveitar o envio de spawn do servidor
        EntityTrackerEntry entrada = new EntityTrackerEntry(mundo(p), p, 1, false, pacote -> { });

        for (ServerPlayerEntity v : server.getPlayerManager().getPlayerList()) {
            boolean ve = vendo.contains(v);
            if (ve) v.networkHandler.sendPacket(new EntitiesDestroyS2CPacket(p.getId()));
            v.networkHandler.sendPacket(remover);
            v.networkHandler.sendPacket(adicionar);
            if (ve) {
                entrada.sendPackets(v, v.networkHandler::sendPacket);
            }
        }
    }

    // ---------- Bússola Lendária ----------
    private static void escolherAlvo(ServerPlayerEntity eu, UUID alvoUuid, Hand hand) {
        ServerPlayerEntity alvo = eu.getServer().getPlayerManager().getPlayer(alvoUuid);
        if (alvo == null) return;

        ItemStack bussola = eu.getStackInHand(hand);
        if (!temId(bussola, BUSSOLA_ID)) {
            bussola = ItemStack.EMPTY;
            for (int i = 0; i < eu.getInventory().size(); i++) {
                ItemStack s = eu.getInventory().getStack(i);
                if (temId(s, BUSSOLA_ID)) { bussola = s; break; }
            }
        }
        if (bussola.isEmpty()) return;

        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, bussola, nbt -> nbt.putString("CsAlvo", alvoUuid.toString()));
        atualizarBussola(bussola, eu.getServer());

        eu.sendMessage(Text.literal("\u00a7aVoc\u00ea Selecionou o Jogador \u00a7f"
            + original(alvo).getName() + " \u00a7acomo alvo"), false);
    }

    private static void atualizarBussola(ItemStack s, MinecraftServer server) {
        NbtComponent dados = s.get(DataComponentTypes.CUSTOM_DATA);
        String a = dados == null ? "" : dados.copyNbt().getString("CsAlvo");
        ServerPlayerEntity alvo = null;
        if (!a.isEmpty()) {
            try {
                alvo = server.getPlayerManager().getPlayer(UUID.fromString(a));
            } catch (IllegalArgumentException ignored) { }
        }

        if (alvo == null) {
            // alvo saiu: volta a apontar para o ponto de ressurgimento do mundo
            if (s.contains(DataComponentTypes.LODESTONE_TRACKER)) {
                s.remove(DataComponentTypes.LODESTONE_TRACKER);
            }
            return;
        }

        BlockPos pos = alvo.getBlockPos();
        GlobalPos nova = GlobalPos.create(alvo.getWorld().getRegistryKey(), pos);
        LodestoneTrackerComponent atual = s.get(DataComponentTypes.LODESTONE_TRACKER);
        boolean atualizar = atual == null || atual.target().isEmpty()
            || !atual.target().get().dimension().equals(nova.dimension())
            || atual.target().get().pos().getSquaredDistance(pos) >= 4;
        if (atualizar) {
            s.set(DataComponentTypes.LODESTONE_TRACKER, new LodestoneTrackerComponent(Optional.of(nova), false));
        }
    }

    // ---------- Menus ----------
    private void abrirSelecao(ServerPlayerEntity player, boolean excluirEu, BiConsumer<ServerPlayerEntity, UUID> acao) {
        List<ServerPlayerEntity> jogadores = new ArrayList<>(player.getServer().getPlayerManager().getPlayerList());
        if (excluirEu) {
            jogadores.remove(player);
        } else {
            jogadores.remove(player);
            jogadores.add(0, player); // quem usou o relógio aparece no primeiro slot
        }

        int linhas = Math.max(1, Math.min(6, (jogadores.size() + 8) / 9));
        SimpleInventory inv = new SimpleInventory(linhas * 9) {
            @Override
            public boolean isValid(int slot, ItemStack stack) {
                return false;
            }
        };
        List<UUID> ids = new ArrayList<>();
        for (int i = 0; i < jogadores.size() && i < linhas * 9; i++) {
            ServerPlayerEntity j = jogadores.get(i);
            inv.setStack(i, cabeca(original(j), !excluirEu && j == player));
            ids.add(j.getUuid());
        }

        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (syncId, pinv, p) -> new MenuSelecao(syncId, pinv, inv, linhas, ids, acao),
            Text.literal("Selecione um jogador")));
    }

    private ItemStack cabeca(GameProfile perfil, boolean verde) {
        ItemStack s = new ItemStack(Items.PLAYER_HEAD);
        s.set(DataComponentTypes.PROFILE, new ProfileComponent(perfil));
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal(perfil.getName())
            .setStyle(Style.EMPTY.withColor(verde ? Formatting.GREEN : Formatting.WHITE).withItalic(false)));
        return s;
    }

    private void abrirMenu(ServerPlayerEntity player) {
        lookup = player.getServer().getRegistryManager();

        SimpleInventory menu = new SimpleInventory(18) {
            @Override
            public boolean isValid(int slot, ItemStack stack) {
                return false;
            }
        };
        menu.setStack(0, criarEspada());
        menu.setStack(1, comBrilho(base(Items.FEATHER, "Pena Lend\u00e1ria", PENA_ID)));
        menu.setStack(2, comRecarga(comBrilho(base(Items.SHIELD, "Escudo Lend\u00e1rio", ESCUDO_ID)), 10.0f, "escudo"));
        menu.setStack(3, criarPocao());
        menu.setStack(4, criarTridente());
        menu.setStack(5, criarPicareta());
        menu.setStack(6, criarCapacete());
        menu.setStack(7, criarDragao());
        menu.setStack(8, comBrilho(base(Items.CLOCK, "Rel\u00f3gio Lend\u00e1rio", RELOGIO_ID)));
        menu.setStack(9, comBrilho(base(Items.SOUL_LANTERN, "Lampi\u00e3o Lend\u00e1rio", LAMPIAO_ID)));
        menu.setStack(10, comBrilho(base(Items.COMPASS, "B\u00fassola Lend\u00e1ria", BUSSOLA_ID)));
        menu.setStack(11, criarBatata());
        menu.setStack(12, criarBota());

        Text titulo = Text.literal("CS").formatted(Formatting.GOLD, Formatting.BOLD)
            .append(Text.literal("\u00bb ").setStyle(Style.EMPTY.withColor(Formatting.GRAY).withBold(false)))
            .append(Text.literal("Rel\u00edquia").setStyle(Style.EMPTY.withColor(Formatting.GRAY).withBold(false)));

        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (syncId, inv, p) -> new MenuReliquia(syncId, inv, menu, 2), titulo));
    }

    private ItemStack base(Item material, String nome, String id) {
        ItemStack stack = new ItemStack(material);
        stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal(nome)
            .setStyle(Style.EMPTY.withColor(Formatting.YELLOW)
                .withBold(true).withUnderline(true).withItalic(true)));
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(false)); // inquebrável, sem aparecer
        NbtCompound nbt = new NbtCompound();
        nbt.putString(TAG, id);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        return stack;
    }

    /** Recarga exclusiva deste item (grupo próprio): escudo, poção e cabeça de dragão normais não ganham recarga. */
    private ItemStack comRecarga(ItemStack s, float segundos, String grupo) {
        s.set(DataComponentTypes.USE_COOLDOWN,
            new UseCooldownComponent(segundos, Optional.of(Identifier.of("csreliquia", grupo))));
        return s;
    }

    /** Só o brilho de encantado, sem encantamento nenhum. */
    private ItemStack comBrilho(ItemStack s) {
        s.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        return s;
    }

    private void encantar(ItemStack s, RegistryKey<Enchantment> chave, int nivel) {
        RegistryEntry<Enchantment> e = lookup.getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(chave);
        s.addEnchantment(e, nivel);
    }

    private ItemStack esconderEncantos(ItemStack s) {
        ItemEnchantmentsComponent c = s.get(DataComponentTypes.ENCHANTMENTS);
        if (c != null) s.set(DataComponentTypes.ENCHANTMENTS, c.withShowInTooltip(false));
        return s;
    }

    private ItemStack criarEspada() {
        ItemStack s = base(Items.GOLDEN_SWORD, "Espada do Ca\u00e7ador", ESPADA_ID);
        encantar(s, Enchantments.KNOCKBACK, 10);
        return esconderEncantos(s);
    }

    private ItemStack criarPocao() {
        ItemStack s = base(Items.SPLASH_POTION, "Po\u00e7\u00e3o Lend\u00e1ria", POCAO_ID);
        // Cor 16711935 (magenta). A nuvem aplica 1/4 da duração: 800 ticks -> 10 s de cegueira
        s.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(
            Optional.empty(), Optional.of(16711935),
            List.of(new StatusEffectInstance(StatusEffects.BLINDNESS, 4, 0)), Optional.empty()));
        s.set(DataComponentTypes.HIDE_ADDITIONAL_TOOLTIP, Unit.INSTANCE);
        encantar(s, Enchantments.UNBREAKING, 1);
        comRecarga(s, 5.0f, "pocao");
        return esconderEncantos(s);
    }

    private ItemStack criarTridente() {
        ItemStack s = base(Items.TRIDENT, "Tridente Lend\u00e1rio", TRIDENTE_ID);
        encantar(s, Enchantments.IMPALING, 5);
        encantar(s, Enchantments.LOYALTY, 3);
        encantar(s, Enchantments.CHANNELING, 1);
        encantar(s, Enchantments.UNBREAKING, 3);
        encantar(s, Enchantments.MENDING, 1);
        return esconderEncantos(s);
    }

    private ItemStack criarPicareta() {
        ItemStack s = base(Items.IRON_PICKAXE, "Picareta Lend\u00e1ria", PICARETA_ID);
        encantar(s, Enchantments.EFFICIENCY, 13);
        return esconderEncantos(s);
    }

    private ItemStack criarDragao() {
        ItemStack s = base(Items.DRAGON_HEAD, "Drag\u00e3o Lend\u00e1rio", DRAGAO_ID);
        comRecarga(s, 10.0f, "dragao");
        encantar(s, Enchantments.UNBREAKING, 1); // encantado, escondido
        return esconderEncantos(s);
    }

    private ItemStack criarBatata() {
        ItemStack s = base(Items.POISONOUS_POTATO, "Batata do Bobo", BATATA_ID);
        encantar(s, Enchantments.UNBREAKING, 1);
        return esconderEncantos(s);
    }

    private ItemStack criarBota() {
        ItemStack s = base(Items.DIAMOND_BOOTS, "Bota Lend\u00e1ria", BOTA_ID);
        encantar(s, Enchantments.PROTECTION, 4);
        encantar(s, Enchantments.FEATHER_FALLING, 4);
        encantar(s, Enchantments.DEPTH_STRIDER, 3);
        encantar(s, Enchantments.SOUL_SPEED, 3);
        encantar(s, Enchantments.THORNS, 3);
        encantar(s, Enchantments.UNBREAKING, 3);
        encantar(s, Enchantments.MENDING, 1);
        return esconderEncantos(s);
    }

    private ItemStack criarCapacete() {
        ItemStack s = base(Items.TURTLE_HELMET, "Capacete Lend\u00e1rio dos G\u00eameos", CAPACETE_ID);
        // +5 cora\u00e7\u00f5es (10 de vida) e mant\u00e9m a armadura original
        s.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.builder()
            .add(EntityAttributes.MAX_HEALTH,
                new EntityAttributeModifier(Identifier.of("csreliquia", "gemeos_vida"), 10.0,
                    EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.HEAD)
            .add(EntityAttributes.ARMOR,
                new EntityAttributeModifier(Identifier.of("csreliquia", "gemeos_armadura"), 2.0,
                    EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.HEAD)
            .build().withShowInTooltip(false));
        encantar(s, Enchantments.UNBREAKING, 1); // encantado, escondido
        return esconderEncantos(s);
    }

    // ---------- Identifica\u00e7\u00e3o dos itens ----------
    public static String idDe(ItemStack stack) {
        if (stack.isEmpty()) return "";
        NbtComponent c = stack.get(DataComponentTypes.CUSTOM_DATA);
        return c == null ? "" : c.copyNbt().getString(TAG);
    }

    public static boolean temId(ItemStack stack, String id) {
        return id.equals(idDe(stack));
    }

    public static boolean isReliquia(ItemStack stack) {
        return !idDe(stack).isEmpty();
    }
}
