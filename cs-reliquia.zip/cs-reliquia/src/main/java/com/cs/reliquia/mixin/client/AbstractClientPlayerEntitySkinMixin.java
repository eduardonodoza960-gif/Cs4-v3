package com.cs.reliquia.mixin.client;

import com.cs.reliquia.CsReliquiaClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntitySkinMixin {

    // Na SUA tela (inventário, terceira pessoa) o seu personagem usa a skin escolhida com /csskin
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "getSkinTextures", at = @At("HEAD"), cancellable = true)
    private void cs$skinEscolhida(CallbackInfoReturnable cir) {
        if (CsReliquiaClient.SKIN_ALVO == null) return;
        AbstractClientPlayerEntity self = (AbstractClientPlayerEntity) (Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (self != mc.player || mc.getNetworkHandler() == null) return;
        PlayerListEntry alvo = mc.getNetworkHandler().getPlayerListEntry(CsReliquiaClient.SKIN_ALVO);
        if (alvo != null) {
            cir.setReturnValue(alvo.getSkinTextures());
        }
    }
}
