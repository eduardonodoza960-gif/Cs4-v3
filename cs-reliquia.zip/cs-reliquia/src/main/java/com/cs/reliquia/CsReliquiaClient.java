package com.cs.reliquia;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

import java.util.UUID;

/**
 * Parte do mod que roda só no seu Minecraft (funciona em qualquer servidor, até sem o mod nele).
 * /csskin <jogador>  -> você passa a ver a skin desse jogador no seu personagem (só na sua tela)
 * /csskin reset      -> volta a sua skin
 */
public class CsReliquiaClient implements ClientModInitializer {

    public static volatile UUID SKIN_ALVO = null;

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("csskin")
                .then(ClientCommandManager.literal("reset").executes(ctx -> {
                    SKIN_ALVO = null;
                    return 1;
                }))
                .then(ClientCommandManager.argument("jogador", StringArgumentType.word())
                    .suggests((ctx, builder) -> {
                        MinecraftClient mc = MinecraftClient.getInstance();
                        if (mc.getNetworkHandler() != null) {
                            for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
                                builder.suggest(e.getProfile().getName());
                            }
                        }
                        return builder.buildFuture();
                    })
                    .executes(ctx -> {
                        String nome = StringArgumentType.getString(ctx, "jogador");
                        MinecraftClient mc = MinecraftClient.getInstance();
                        if (mc.getNetworkHandler() != null) {
                            for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
                                if (e.getProfile().getName().equalsIgnoreCase(nome)) {
                                    SKIN_ALVO = e.getProfile().getId();
                                    break;
                                }
                            }
                        }
                        return 1;
                    }))));
    }
}
